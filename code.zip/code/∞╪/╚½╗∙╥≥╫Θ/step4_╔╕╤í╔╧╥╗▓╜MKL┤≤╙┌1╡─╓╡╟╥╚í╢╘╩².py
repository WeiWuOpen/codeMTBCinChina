


inputFolder=r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step2_kl以及差异倍数\\"
outputFolder=r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step2_2_kl以及差异倍数_取对数\\"

import os
import math

if not os.path.exists(outputFolder):
    os.mkdir(outputFolder)


fileList=os.listdir(inputFolder)

for ff in fileList:
    inputGeneList=[]
    inputKLlist=[]
    inputMKLlist=[]
    with open(inputFolder+ff,"r") as input:
        for ll in input:
            llx=ll.strip().split()
            if llx[0] !="Gene":
                inputGeneList.append(llx[0])
                inputKLlist.append(llx[1])
                if float(llx[2]) >1:
                    inputMKLlist.append(float(llx[2]))
                elif float(llx[2]) ==1:
                    inputMKLlist.append(1+1E-12) # 加个极小值
            else:
                title=ll.strip().replace("MKL","lg(MKL-1)")

    reMKLlist=[]
    for ii in inputMKLlist:
        reMKLlist.append(math.log(ii-1,10))

    with open(outputFolder+ff.replace(".txt","")+"_reMKL.txt","w") as output:
        output.write(title+"\n")
        for qq in range (0,len(reMKLlist)):
            output.write(inputGeneList[qq]+"\t"+inputKLlist[qq]+"\t"+str(reMKLlist[qq])+"\n")

print("finished!!!!")




