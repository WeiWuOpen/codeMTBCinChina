


geneGroupList = ["休眠和复苏阶段基因", "巨噬细胞感染阶段基因", "必需基因","假基因","高相对熵基因"]

inputFolder=r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step1_区分全部编码和非编码功能区\\"

outputFolder=r"F:\forStudy\studysite\熵\从全基因组结果中寻找目标基因群\\"


import os


cladeList=[]
fileList=os.listdir(inputFolder)
for ff in fileList:
    cladeList.append(ff.split("_")[0])


for gr in geneGroupList:
    inputGeneListFile=r"F:\forStudy\studysite\熵\从全基因组结果中寻找目标基因群\\" + gr +".txt"

    outputFolder2=outputFolder+gr+"\\"
    if not os.path.exists(outputFolder2):
        os.mkdir(outputFolder2)

    geneList=[]
    with open(inputGeneListFile,"r") as input:
        for ll in input:
            llx=ll.strip().split("\t")
            geneList.append(llx[0])

    for cc in cladeList:
        resultlist=[]
        with open(inputFolder+cc+"_相对于aMTBC的交叉熵和相对熵_全部编码和非编码功能区.txt","r") as input:
            for l in input:
                lx=l.strip().split("\t")
                if lx[0] in geneList:
                    if float(lx[-1]) >= 0: # 熵增的
                        resultlist.append(lx[0]+"\t"+lx[4])
                    elif float(lx[-1]) < 0: # 熵减的
                        resultlist.append(lx[0] + "\t" + "-"+lx[4]) # 加负号
                else:
                    continue
        with open(outputFolder2+cc+"_"+"KLvalue.txt","w") as output:
            # output.write("Gene"+"\t"+cc.replace("ONLYchina","").replace("NOchina","")+"_"+"KLvalue"+"\n")
            output.write("L"+cc.replace("ONLYchina","").replace("NOchina","")+"\n")
            for rr in resultlist:
                output.write(rr.split("\t")[1]+"\n")


print("finished!!!!!")





