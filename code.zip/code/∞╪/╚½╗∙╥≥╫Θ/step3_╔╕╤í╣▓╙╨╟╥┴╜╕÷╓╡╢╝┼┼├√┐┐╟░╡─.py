
inputFolder = r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step2_kl以及差异倍数\\"

outputFolder = r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step3_筛选共有且两个值都排名靠前的\\"




cutLimitRate = 0.15 # 取前面的比例

import os
import numpy as np
from collections import Counter
import math

if not os.path.exists(outputFolder):
    os.mkdir(outputFolder)

fileList = os.listdir(inputFolder)

cladeNum=len(fileList)
print("cladeNum: "+str(cladeNum))

GeneList=[]
inputDict2={}
for ff in fileList:
    inputDict={}
    klList=[]
    difKLlist=[]
    with open(inputFolder+ff,"r") as input:
        for ll in input:
            llx=ll.strip().split()
            if llx[0] !="Gene":
                inputDict[llx[0]]=[float(llx[1]),float(llx[2])]
                klList.append(float(llx[1]))
                difKLlist.append(float(llx[2]))
    inputDict2[ff.split("_")[0]] =inputDict
    sortklList=sorted(klList)
    sortdifKLlist=sorted(difKLlist)

    kllimitValueIndex=int( (1-cutLimitRate) * len(sortklList) ) -1
    kllimitValue=sortklList[kllimitValueIndex]

    difKLlimitValueIndex=int( (1-cutLimitRate) * len(sortdifKLlist) ) -1
    difKLlimitValue=sortdifKLlist[difKLlimitValueIndex]

    for kk in inputDict.keys():
        if inputDict[kk][0] >= kllimitValue and inputDict[kk][1] >= difKLlimitValue:
        # if inputDict[kk][0] >= kllimitValue and inputDict[kk][1] > 0:
            GeneList.append(kk)

    del inputDict

commonGeneList=[]
GeneDict=dict(Counter(GeneList))
for cc in GeneDict.keys():
    if GeneDict[cc] == cladeNum:
        commonGeneList.append(cc)
    elif GeneDict[cc] > cladeNum:
        print("Wrong in gene number !!!!!!")
    else:
        continue

print("After filered Genes Number: " +str(len(commonGeneList)))

for rr in inputDict2.keys():
    with open(outputFolder+rr+"_进一步筛选共有_"+str(cutLimitRate)+".txt","w") as output:
        output.write("Gene" + "\t" + "KL_" + rr + "\t" + "MKL_" + rr + "\n")
        for g in inputDict2[rr].keys():
            if g in commonGeneList:
                output.write(g + "\t" + str(inputDict2[rr][g][0]) + "\t" + str(inputDict2[rr][g][1]) + "\n")

print("finished!!!!")















