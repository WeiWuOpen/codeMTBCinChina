

inputFile=r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step1_区分全部编码和非编码功能区\kl_df_CDS.txt"
outputFile=r"F:\forStudy\studysite\熵\全基因组_refaMTBC3\step1_区分全部编码和非编码功能区\rkl_cds.txt"


resultList=[]
with open(inputFile,"r") as input:
    for l in input:
        lx=l.strip().split()
        if lx[0] !="Gene":
            if float(lx[-1]) >=0:
                resultList.append(lx[0]+"\t"+lx[1])
            else:
                resultList.append(lx[0]+"\t"+"-"+lx[1])

with open(outputFile,"w") as output:
    output.write("Gene"+"\t"+"rkl_real"+"\n")
    for rr in resultList:
        output.write(rr+"\n")

print("finished!!!!!")