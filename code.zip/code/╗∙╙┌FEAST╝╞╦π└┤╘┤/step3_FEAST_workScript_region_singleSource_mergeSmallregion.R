#!/usr/bin/env Rscript

# 清理工作环境
rm(list = ls())

workDir=paste("F:/forStudy/studysite/regionSource_FEAST/step3_FEAST_singleSource_mergeSamllregion/")
otuDir=paste("F:/forStudy/studysite/regionSource_FEAST/step1_2_SNP_wholeGenomeCDS_smallRegion/")
metadataDir=paste("F:/forStudy/studysite/regionSource_FEAST/step2_single_sourceSink_mergeSmallregion/")
otuFileName="4.5_SNP_allCDS_smallRegion_matrix.txt"
# metaFileName="4.4_sourceSink_metadata_singleSource_mergeSmallregion_West_Europe.txt"
metaFileName="4.5_sourceSink_metadata_singleSource_mergeSmallregion_South_China.txt"
outputFileName=paste("4.5")
outPutDir=workDir

setwd(workDir)


# 这是安装依赖的步骤
# devtools::install_github("cozygene/FEAST")


# Packages <- c("Rcpp", "RcppArmadillo", "vegan", "dplyr", "reshape2", "gridExtra", "ggplot2", "ggthemes")
Packages <- c("Rcpp", "RcppArmadillo", "vegan", "dplyr", "reshape2", "gridExtra", "ggthemes")
lapply(Packages, library, character.only = TRUE)

library("FEAST")
metadata <- Load_metadata(metadata_path = paste0(metadataDir,metaFileName))
otus <- Load_CountMatrix(CountMatrix_path = paste0(otuDir,otuFileName))


# run FEAST
FEAST_output <- FEAST(C = otus, metadata = metadata, different_sources_flag = 0, dir_path = outPutDir,
                      outfile=outputFileName)

FEAST_output=paste0(outPutDir,outputFileName,"_singleSource_smallRegion_contributions_matrix.txt")





