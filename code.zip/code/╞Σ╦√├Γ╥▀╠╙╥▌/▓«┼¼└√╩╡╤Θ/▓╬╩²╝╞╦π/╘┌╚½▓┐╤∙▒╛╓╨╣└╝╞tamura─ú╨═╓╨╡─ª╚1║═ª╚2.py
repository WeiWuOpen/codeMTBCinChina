cladeName="all_Liu.exceptAnimal_NOCanetti"
# cladeName="9"
#################################################
# 特别注意，对于参考基因组上的任意碱基，潜在突变的θ1和θ2是不一样的，对于G\C，潜在θ2=2θ1；对于A\T，潜在θ1=2θ2（因为不能自己向自己本身突变）所以需要考虑参考基因组本身的GC、AT比例进行修正
# 详见相关算法公式推导
##################################################


inputlistFile="G:\\aaaworksite\mtbc基因组数据总结\\"+cladeName+".txt"
inputvcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf_ancestralREFseq\REFseq_MTBC\\"
# inputvcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"
inputuncoverFolder=r"G:\aaaworkfilestore\TB\store_alluncover.bed\\"
inputCodonBiasFile=r"G:\aaaworkfilestore\TB\H37Rv密码子偏好性.txt"
inputrefseqFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\refseq\H37Rv_r.fasta"
inputrefseqSNPFile_new = r"F:\forStudy\studysite\ancestralSeq\aMTBC_noCanetti_withprd.fasta"
inputrefseqPOSFile_new = r"F:\forStudy\studysite\ancestralSeq\all_Liu.exceptAnimal_withCanetti_refH37Rv_withprd.pos.txt"


outputfile="F:\\forStudy\studysite\伯努利实验补\\"+cladeName +  "_tamura模型中的θ1和θ2.txt"
outputfile2="F:\\forStudy\studysite\伯努利实验补\\"+cladeName +  "_高unver样本.txt"



#########################################################################################################

refseqdict={}
with open(inputrefseqFile,"r") as input:
    for l in input:
        if l.strip()[0] !=">":
            refseq=list(l.strip())
for i in range(1,len(refseq)+1):
    refseqdict[int(i)] = refseq[i-1]

newRefseqdict={}
newRefPoslist=[]
with open(inputrefseqSNPFile_new,"r") as input, open(inputrefseqPOSFile_new,"r") as inputpos:
    for l in input:
        if l.strip()[0] != ">":
            newrefseq = list(l.strip())
    for ll in inputpos:
        newRefPoslist.append(ll.strip())
for i in range(0,len(newrefseq)):
    newRefseqdict[int(newRefPoslist[i])] = newrefseq[i]

allLongNewRefseqdict={}
for k in refseqdict.keys():
    if k in newRefseqdict.keys() and newRefseqdict[k] !="-":
        allLongNewRefseqdict[k] = newRefseqdict[k]
    else:
        allLongNewRefseqdict[k] = refseqdict[k]

anti_allLongNewRefseqdict={}
baseDict={"A":"T","T":"A","C":"G","G":"C"}
for baseindex in allLongNewRefseqdict.keys():
    anti_allLongNewRefseqdict[baseindex] = baseDict[allLongNewRefseqdict[baseindex]]


## 这个其实是用来翻译密码子的
condonBiasDict = {}
condonBiaslist = []
with open(inputCodonBiasFile, "r") as input:
    for l in input:
        lx = l.strip().split()
        if lx != [] and lx[0] != "Coding":
            condonBiaslist.append(l.strip().replace("U", "T"))

for ll in condonBiaslist:
    llx = ll.strip().split()
    condonBiasDict[llx[0]] = [llx[1], llx[3]]
    condonBiasDict[llx[6]] = [llx[7], llx[9]]
    condonBiasDict[llx[12]] = [llx[13], llx[15]]
    condonBiasDict[llx[18]] = [llx[19], llx[21]]

strainlist=[]
with open (inputlistFile,"r") as input:
    for l in input:
        strainlist.append(l.strip())


vcfdict={}
beddict={}
for i in strainlist:
    vcfdict[i] = []
    beddict[i] = []
    # with open(inputvcfFolder + i +".recode.vcf","r") as inputvcf,open(inputuncoverFolder+i+".uncover.bed","r") as inputbed:
    with open(inputvcfFolder + i +".recode.ancestralREFseq.vcf","r") as inputvcf,open(inputuncoverFolder+i+".uncover.bed","r") as inputbed:
        for line in inputbed:
            linex=line.strip().split()
            beddict[i].append(linex[1] + "_"+ linex[2])
        for l in inputvcf:
            if l.strip()[0] != "#":
                # 去除indel
                if len(l.strip().split()[3]) == 1 and len(l.strip().split()[4]) == 1:
                    vcfdict[i].append(l.strip().split()[1]+"_"+l.strip().split()[3]+"_"+l.strip().split()[4])


# print(vcfdict)

rate1List=["AG","TG","CG","AC","TC","GC"]
rate2List=["TA","CA","GA","AT","CT","GT"]


# 获取参考基因组上A、T碱基数目Nat和G、C碱基数目Ngc
Nat=0
Ngc=0
for iii in allLongNewRefseqdict.keys():
    if allLongNewRefseqdict[iii] =="A" or allLongNewRefseqdict[iii] =="T":
        Nat +=1
    elif allLongNewRefseqdict[iii] == "G" or allLongNewRefseqdict[iii] == "C":
        Ngc +=1
    else:
        print("wrong base in refSeq !!!!!!!!")
        print(allLongNewRefseqdict[iii])

# print(len(allLongNewRefseqdict))
# print(Nat)
# print(Ngc)


####################################################
highUncoverDict={}
n=0
resultDict={}
for dd in vcfdict.keys():
    n += 1
    print(cladeName + "\t" + str(n) + "/" + str(len(vcfdict.keys())))
    # 避免遇到无突变样本
    if vcfdict[dd] !=[]:
        allNum=0
        allsnpNum = 0
        rate1Num=0
        rate2Num=0
        unum = 0
        for rr in vcfdict[dd]:
            allNum+=1
            uncoverlist = []
            for u in beddict[dd]:
                if int(u.split("_")[0]) <= int(rr.split("_")[0]) <= int(u.split("_")[1]):
                    uncoverlist.append("uncover")
                    unum +=1
                    break
                else:
                    continue
            if len(uncoverlist) != 0:
                continue
                print(rr)
            else:
                allsnpNum +=1
                refbase=rr.split("_")[1]
                altbase=rr.split("_")[2]
                changetype=refbase+altbase
                if changetype in rate1List:
                    rate1Num +=1
                elif changetype in rate2List:
                    rate2Num +=1
                else:
                    print("wrong in changetype !!!!!!!!!!!!!")
                    print(changetype)
        # 避免遇到去除uncover后无突变的样本
        if allsnpNum ==0:
            continue
        else:
            if allsnpNum/allNum >=0.97:
                aa=(rate1Num/rate2Num)* ((Nat+2*Ngc)/(Ngc+2*Nat))
                rate1=aa/(1+aa)
                rate2=1-rate1
                resultDict[dd]=[rate1,rate2]
                del rate1
                del rate2
            else:
                highUncoverDict[dd]=allsnpNum/allNum
                print(allsnpNum/allNum)



# print(resultDict)
with open(outputfile,"w") as output:
    output.write("Accession"+"\t"+"Rateθ1"+"\t"+"Rateθ2"+"\n")
    for kk in resultDict.keys():
        output.write(kk+"\t"+str(resultDict[kk][0])+"\t"+str(resultDict[kk][1])+"\n")

with open(outputfile2,"w") as output:
    for hh in highUncoverDict.keys():
        output.write(hh+"\t"+str(highUncoverDict[hh])+"\n")


print("finished!!!!")
