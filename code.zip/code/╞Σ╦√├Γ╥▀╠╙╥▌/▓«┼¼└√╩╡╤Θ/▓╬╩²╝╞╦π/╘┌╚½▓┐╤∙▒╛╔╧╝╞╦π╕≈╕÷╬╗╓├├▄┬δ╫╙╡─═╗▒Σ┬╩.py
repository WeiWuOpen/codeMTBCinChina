cladeName="all_Liu.exceptAnimal_NOCanetti"


inputlistFile="G:\\aaaworksite\mtbc基因组数据总结\\"+cladeName+".txt"
inputvcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf_ancestralREFseq\REFseq_MTBC\\"
# inputvcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"
inputuncoverFolder=r"G:\aaaworkfilestore\TB\store_alluncover.bed\\"
inputrefseqFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\refseq\H37Rv_r.fasta"
inputrefseqSNPFile_new = r"F:\forStudy\studysite\ancestralSeq\aMTBC_noCanetti_withprd.fasta"
inputrefseqPOSFile_new = r"F:\forStudy\studysite\ancestralSeq\all_Liu.exceptAnimal_withCanetti_refH37Rv_withprd.pos.txt"
inputGenefile = r"G:\aaaworkfilestore\TB\TB_annatationfile\H37Rv.annotation_all.txt"


outputfile1="F:\\forStudy\studysite\伯努利实验补\\"+cladeName +  "_全部基因上SNP位点密码子位置的比例.txt"
outputfile3="F:\\forStudy\studysite\伯努利实验补\\"+cladeName +  "_高unver样本.txt"



#########################################################################################################
refseqdict={}
with open(inputrefseqFile,"r") as input:
    for l in input:
        if l.strip()[0] !=">":
            refseq=list(l.strip())
for i in range(1,len(refseq)+1):
    refseqdict[int(i)] = refseq[i-1]

newRefseqdict={}
newRefPoslist=[]
with open(inputrefseqSNPFile_new,"r") as input, open(inputrefseqPOSFile_new,"r") as inputpos:
    for l in input:
        if l.strip()[0] != ">":
            newrefseq = list(l.strip())
    for ll in inputpos:
        newRefPoslist.append(ll.strip())
for i in range(0,len(newrefseq)):
    newRefseqdict[int(newRefPoslist[i])] = newrefseq[i]

allLongNewRefseqdict={}
for k in refseqdict.keys():
    if k in newRefseqdict.keys() and newRefseqdict[k] !="-":
        allLongNewRefseqdict[k] = newRefseqdict[k]
    else:
        allLongNewRefseqdict[k] = refseqdict[k]

anti_allLongNewRefseqdict={}
baseDict={"A":"T","T":"A","C":"G","G":"C"}
for baseindex in allLongNewRefseqdict.keys():
    anti_allLongNewRefseqdict[baseindex] = baseDict[allLongNewRefseqdict[baseindex]]



strainlist=[]
with open (inputlistFile,"r") as input:
    for l in input:
        strainlist.append(l.strip())


vcfdict={}
beddict={}
for i in strainlist:
    vcfdict[i] = []
    beddict[i] = []
    # with open(inputvcfFolder + i +".recode.vcf","r") as inputvcf,open(inputuncoverFolder+i+".uncover.bed","r") as inputbed:
    with open(inputvcfFolder + i +".recode.ancestralREFseq.vcf","r") as inputvcf,open(inputuncoverFolder+i+".uncover.bed","r") as inputbed:
        for line in inputbed:
            linex=line.strip().split()
            beddict[i].append(linex[1] + "_"+ linex[2])
        for l in inputvcf:
            if l.strip()[0] != "#":
                # 去除indel
                if len(l.strip().split()[3]) == 1 and len(l.strip().split()[4]) == 1:
                    vcfdict[i].append(l.strip().split()[1]+"_"+l.strip().split()[3]+"_"+l.strip().split()[4])

geneDict={}
with open(inputGenefile,"r") as input:
        for l in input:
            lx=l.strip().split("\t")
            if lx[2] =="CDS":
                if lx[0][-1] =="c":
                    geneDict[lx[0]]=lx[3]+"_"+lx[4] +"_"+"c"
                else:
                    geneDict[lx[0]] = lx[3] + "_" + lx[4] + "_" + "f"


####################################################
highUncoverDict={}

n=0
fDict={}
sDict={}
tDict={}
for dd in vcfdict.keys():
    fcodonNum = 0
    scodonNum = 0
    tcodonNum = 0
    n += 1
    print(cladeName + "\t" + str(n) + "/" + str(len(vcfdict.keys())))
    # 避免遇到无突变样本
    if vcfdict[dd] !=[]:
        allNum=0
        unum = 0
        for p in vcfdict[dd]:
            allNum+=1
            uncoverlist = []
            for u in beddict[dd]:
                if int(u.split("_")[0]) <= int(p.split("_")[0]) <= int(u.split("_")[1]):
                    uncoverlist.append("uncover")
                    unum +=1
                    break
                else:
                    continue
            if len(uncoverlist) != 0:
                continue
                # print(p)
            else:
                codonpos=0
                for g in geneDict.keys():
                    if int(geneDict[g].split("_")[0]) <= int(p.split("_")[0]) <= int(geneDict[g].split("_")[1]):
                        if geneDict[g].split("_")[2] == "f":
                            if (int(p.split("_")[0]) - int(geneDict[g].split("_")[0]) + 1) % 3 == 1:
                                codonpos = 1

                            elif (int(p.split("_")[0]) - int(geneDict[g].split("_")[0]) + 1) % 3 == 2:
                                codonpos = 2

                            else:
                                codonpos = 3

                        else:
                            if (int(geneDict[g].split("_")[1]) - int(p.split("_")[0]) + 1) % 3 == 1:
                                codonpos = 1
                            elif (int(geneDict[g].split("_")[1]) - int(p.split("_")[0]) + 1) % 3 == 2:
                                codonpos = 2
                            else:
                                codonpos = 3

                        break

                if codonpos == 0:
                    continue
                else:
                    if codonpos ==1:
                        fcodonNum +=1
                    elif codonpos ==2:
                        scodonNum +=1
                    elif codonpos ==3:
                        tcodonNum +=1
                    else:
                        print("wrong!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        allcodonNum = fcodonNum + scodonNum + tcodonNum
        frate = fcodonNum / allcodonNum
        srate = scodonNum / allcodonNum
        trate = tcodonNum / allcodonNum
        fDict[dd] =frate
        sDict[dd] =srate
        tDict[dd] =trate


with open(outputfile1,"w") as output:
    output.write("Accession"+"\t"+"FirstBaseSNPRate"+"\t"+"SecondBaseRate"+"\t"+"ThirdBaseRate"+"\n")
    for kk in fDict.keys():
        output.write(kk+"\t"+str(fDict[kk])+"\t"+str(sDict[kk])+"\t"+str(tDict[kk])+"\n")


with open(outputfile3,"w") as output:
    for hh in highUncoverDict.keys():
        output.write(hh+"\t"+str(highUncoverDict[hh])+"\n")


print("finished!!!!")
