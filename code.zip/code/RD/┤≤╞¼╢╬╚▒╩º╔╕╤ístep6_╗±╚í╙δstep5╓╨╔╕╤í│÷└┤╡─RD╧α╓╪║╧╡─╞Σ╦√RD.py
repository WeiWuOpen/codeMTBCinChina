

inputfile=r"F:\forStudy\studysite\RDworksite\step2_2\RD_regionx_merge.txt"
inputfile2=r"F:\forStudy\studysite\RDworksite\step3\RD_filterUncover_filterRD.txt"
inputlistfolder=r"F:\forStudy\studysite\RDworksite\step5\0.1\\"
outputfilefold=r"F:\forStudy\studysite\RDworksite\step6\\"
outputfile1=outputfilefold+"cladeRD_uniqueTESTresult_0.75overlap.txt"
outputfile2=outputfilefold+"cladeRD_uniqueTESTresult.txt"

import os
import numpy as np


overlapRateLimit=0.75
existRateLimit=0.1


if os.path.exists(outputfilefold) !=True:
    os.mkdir(outputfilefold)

RDnamelist=[]
fileList=os.listdir(inputlistfolder)
for f in fileList:
    if f[0:2]=="RD":
        RDnamelist.append(f.split("_")[0]+"_"+f.split("_")[1])

RDnamelist=np.unique(RDnamelist)


existRateDict={}
with open(inputfile2,"r") as input:
    for ll in input:
        llx=ll.strip().split()
        if llx[0] !="Strain":
            if llx[6] not in existRateDict.keys():
                existRateDict[llx[6]] = llx[7]

inputlist=[]
with open(inputfile,"r") as input:
    for line in input:
        linex=line.strip().split()
        if linex[0] != "RD":
            if linex[0] in existRateDict.keys(): # 注意：由于step3结果已经过滤掉了存在率低于0.1的RD，所以这里默认过滤了这些
                if float(existRateDict[linex[0]]) >= existRateLimit: # 过滤低存在率的RD
                    inputlist.append(line.strip())

RDnamedict={}
for i in RDnamelist:
    for ii in inputlist:
        if ii.split()[0] == i:
            RDnamedict[i] = [ii.split()[2].split("-")[0],ii.split()[2].split("-")[1],ii.split()[1].split("-")[0],ii.split()[1].split("-")[1]]

linedict={}
for ii in inputlist:
    linedict[ii.split()[0]] = [ii.split()[2].split("-")[0],ii.split()[2].split("-")[1],ii.split()[1].split("-")[0],ii.split()[1].split("-")[1]]


resultdict={}
for k in RDnamedict.keys():
    key=k + "+" + str(RDnamedict[k][0]) + "-" + str(RDnamedict[k][1]) + "+" + str(RDnamedict[k][2]) + "-" + str(RDnamedict[k][3])+"+"+existRateDict[k]
    resultdict[key] = []
    for kk in linedict.keys():
        if k != kk and k.split("_")[0] != kk.split("_")[0]:
            # 以最小范围的交集作为评价标准
            if int(RDnamedict[k][2]) <= int(linedict[kk][2]) <= int(RDnamedict[k][3])\
                or int(RDnamedict[k][2]) <= int(linedict[kk][3]) <= int(RDnamedict[k][3])\
                or int(linedict[kk][2]) <= int(RDnamedict[k][2]) <= int(RDnamedict[k][3]) <= int(linedict[kk][3]):
                overlaplength=min(int(RDnamedict[k][3]),int(linedict[kk][3])) -\
                    max(int(RDnamedict[k][2]),int(linedict[kk][2])) +1
                RDlength=int(RDnamedict[k][3]) - int(RDnamedict[k][2]) +1
                overlaprate=overlaplength / RDlength
                resultdict[key]\
                    .append(kk +"+"+str(linedict[kk][0])+"-" + str(linedict[kk][1])+"+"+str(overlaprate) +"+"+str(linedict[kk][2])+"-" + str(linedict[kk][3])+"+"+existRateDict[kk])

    if len(resultdict[key]) == 0:
        resultdict[key].append("unique")

with open(outputfile2,"w") as output:
    for ll in resultdict.keys():
        output.write(ll.replace("+","\t") + "\t" + "\t")
        for i in resultdict[ll]:
            output.write(i + "\t")
            # output.write(i.replace("+","\t")  + "\t")
        output.write("\n")

with open(outputfile1,"w") as output:
    for ll in resultdict.keys():
        output.write(ll.replace("+","\t") + "\t" + "\t")
        for i in resultdict[ll]:
            if i.split("+")[-1] == "unique":
                output.write(i + "\t")
            elif float(i.split("+")[-3]) >= overlapRateLimit:
                output.write(i + "\t")
             # output.write(i.replace("+","\t")  + "\t")
        output.write("\n")