inputRDfile= r"F:\forStudy\studysite\RDworksite\step3\RD_filterUncover_filterRD.txt"
inputAnnotationFile= r"G:\aaaworkfilestore\TB\TB_annatationfile\H37Rv.annotation_all.txt"
outputfold= r"F:\forStudy\studysite\RDworksite\step4\\"
outputfile= outputfold+"RD_filterUncover_filterRD_findRegion.txt"


import os

if os.path.exists(outputfold) !=True:
    os.mkdir(outputfold)

genedict={}
with open(inputAnnotationFile,"r") as inputanno:
    for line in inputanno:
        linex=line.strip().split()
        genedict[linex[0]]=[linex[3],linex[4],linex[2]]


RDlist=[]
with open(inputRDfile, "r") as inputRD:
    for l in inputRD:
        lx=l.strip().split()
        if lx[0] != "Strain":

            RDlist.append("_".join(lx[0:6]) + "_" +lx[6].replace("_","-") + "_" + lx[7])

resultlist=[]
nn=0
for s in RDlist:
    nn+=1
    print(str(nn)+"/"+str(len(RDlist)))
    resultlistx=[]
    for ss in genedict.keys():
        if int(s.split("_")[2]) <= int(genedict[ss][0])  <= int(genedict[ss][1])  <= int(s.split("_")[3]):
            overrate = 1
            resultlistx.append(s + "_" + ss + "_" + "RegionInRD" + "_" + genedict[ss][0] + "_" + genedict[ss][1] + "_" +genedict[ss][2] + "_" + str(overrate))
        elif int(s.split("_")[2]) <= int(genedict[ss][0])  <= int(s.split("_")[3])\
            or int(s.split("_")[2]) <= int(genedict[ss][1])  <= int(s.split("_")[3]):
            overlaplength=min(int(s.split("_")[3]),int(genedict[ss][1]))-max(int(s.split("_")[2]),int(genedict[ss][0]))
            genelength=(int(genedict[ss][1])) - (int(genedict[ss][0]))
            overrate=overlaplength/genelength
            resultlistx.append(s + "_" + ss + "_" + "PartialOverlap" + "_" + genedict[ss][0] + "_" + genedict[ss][1] + "_" +genedict[ss][2] + "_" + str(overrate))
        elif  int(genedict[ss][0])  <= int(s.split("_")[2]) <= int(s.split("_")[3])  <= int(genedict[ss][1]):
            RDlength=int(s.split("_")[3]) - int(s.split("_")[2])
            genelength = int(genedict[ss][1]) - int(genedict[ss][0])
            overrate=RDlength/genelength
            resultlistx.append(s + "_" + ss + "_" + "InsideRegion" + "_" + genedict[ss][0] + "_" + genedict[ss][1] + "_" +genedict[ss][2] + "_" + str(overrate))
    if len(resultlistx) ==0:
        resultlistx.append(s + "_" + "-" + "_" + "Outside" + "_" + "-" + "_" + "-"+ "_" +genedict[ss][2] + "_" + "-")

    resultlist=resultlist + resultlistx


title="Strain	Clade	StartPosition	EndPosition	Coverage_uncover/RD	Covered_region	RD	RD_presenceRate	Region	Relationship	RegionStartPosition	RegionEndPosition	RegionType  	coverage_overlap/region"
with open(outputfile,"w") as output:
    output.write(title + "\n")

    for r in resultlist:
        output.write(r.replace("_","\t") + "\n")


