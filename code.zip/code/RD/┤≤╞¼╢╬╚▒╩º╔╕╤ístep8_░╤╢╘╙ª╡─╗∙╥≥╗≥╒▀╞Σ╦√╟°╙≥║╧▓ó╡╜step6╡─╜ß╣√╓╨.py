inputFile=r"F:\forStudy\studysite\RDworksite\step6\cladeRD_uniqueTESTresult_0.75overlap_去重复_中国枝有的.txt"
inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\H37Rv.annotation_all.txt"
outputFolder=r"F:\forStudy\studysite\RDworksite\step8\\"

import os

if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)

inputDict={}
m=0
with open(inputFile,"r") as input:
    for ll in input:
        m+=1
        llx=ll.strip().split()
        inputDict["group"+str(m)] = [[llx[0],llx[1],llx[2],llx[3]]]
        if len(llx[4:]) ==0:
            continue
        else:
            if llx[4] == "unique":
                continue
            else:
                for tt in llx[4:]:
                    ttx=tt.split("+")
                    inputDict["group"+str(m)].append([ttx[0],ttx[1],ttx[3]])

inputAnnotationDict={}
with open(inputAnnotationFile,"r") as input:
    for l in input:
        lx=l.strip().split()
        inputAnnotationDict[lx[0]] = [lx[2],int(lx[3]),int(lx[4])]

for gr in inputDict.keys():
    resultDict={}
    for rd in inputDict[gr]:
        maxl=int(rd[1].split("-")[0])
        maxr = int(rd[1].split("-")[1])
        minl = int(rd[2].split("-")[0])
        minr = int(rd[2].split("-")[1])
        maxList=[]
        minList=[]
        resultDict[rd[0]] = [rd[1],rd[2],rd[3]]
        for rr in inputAnnotationDict.keys():
            rrl=inputAnnotationDict[rr][1]
            rrr=inputAnnotationDict[rr][2]
            if maxl <= rrl <= maxr or maxl <= rrr <= maxr or rrl <= maxl <= maxr <= rrr:
                maxList.append(rr+"_"+inputAnnotationDict[rr][0])
            if minl <= rrl <= minr or minl <= rrr <= minr or rrl <= minl <= minr <= rrr:
                minList.append(rr+"_"+inputAnnotationDict[rr][0])
            else:
                continue
        resultDict[rd[0]].append(maxList)
        resultDict[rd[0]].append(minList)
    with open(outputFolder+gr+".txt","w") as output:
        output.write("RD"+"\t"+"ExistRate"+"\t"+"MaxRegion"+"\t"+"RelativeStructure_max"+"\t"+"MinRegion"+"\t"+"RelativeStructure_min"+"\n")
        for kk in resultDict.keys():
            output.write(kk+"\t"+resultDict[kk][2]+"\t"+resultDict[kk][0]+"\t"+"|".join(resultDict[kk][3])+"\t"+resultDict[kk][1]+"\t"+"|".join(resultDict[kk][4])+"\n")


print("finished!!!!!")
            
