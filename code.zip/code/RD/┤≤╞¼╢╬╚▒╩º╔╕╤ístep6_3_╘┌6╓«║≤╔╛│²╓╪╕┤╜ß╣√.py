inputFile=r"F:\forStudy\studysite\RDworksite\step6\cladeRD_uniqueTESTresult_0.75overlap.txt"
inputFile2=r"F:\forStudy\studysite\RDworksite\step4\RD_filterUncover_filterRD_findRegion.txt"
outputFile=r"F:\forStudy\studysite\RDworksite\step6\cladeRD_uniqueTESTresult_0.75overlap_去重复.txt"

inputDict1={}
inputDict2={}
with open(inputFile,"r") as input:
    for l in input:
        lx=l.strip().split()
        inputDict1[lx[0]] = l.strip()
        inputDict2[lx[0]] = [lx[0]+"+"+lx[1]+"+"+lx[2]]
        for i in lx[4:]:
            if i !="unique":
                ix=i.split("+")
                inputDict2[lx[0]].append(ix[0]+"+"+ix[1]+"+"+ix[3])

resultKeyList1=[]
keytmpList=[]
for k in inputDict2.keys():
    if k not in keytmpList:
        keytmpList.append(k)
        resultKeyList1.append(k)
        for kk in inputDict2.keys():
            if kk != k:
                setx= set(inputDict2[k]) & set(inputDict2[kk]) # 取交集
                listx=list(setx)
                if len(listx) == len(inputDict2[k]) and len(listx) == len(inputDict2[kk]):
                    keytmpList.append(kk)
    else:
        continue



with open(outputFile,"w") as output:
    for ss in resultKeyList1:
        output.write(inputDict1[ss]+"\n")



