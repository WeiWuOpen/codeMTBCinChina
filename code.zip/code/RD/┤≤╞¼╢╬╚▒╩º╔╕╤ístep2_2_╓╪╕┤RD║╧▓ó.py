inputfolder=r"F:\forStudy\studysite\RDworksite\step2\\"
outputfilefold=r"F:\forStudy\studysite\RDworksite\step2_2\\"


import os
import numpy as np


if os.path.exists(outputfilefold) !=True:
    os.mkdir(outputfilefold)

fileList=os.listdir(inputfolder)

rdinputDict={}
with open(inputfolder+"RD_regionx.txt","r") as input:
    for ll in input:
        llx=ll.strip().split()
        if llx[0]=="RD":
            title=ll.strip()
        else:
            rdinputDict[llx[0]] = [llx[1],llx[2]]

inputStrainDict={}
for f in fileList:
    if f !="RD_regionx.txt":
        with open(inputfolder+f,"r") as input:
            for l in input:
                lx=l.strip().split()
                inputStrainDict[lx[0]] = lx[1:]

resultStrainDict={}
rdresultDict={}
tmprdList=[]
for key in rdinputDict.keys():
    if key not in tmprdList:
        smallL = int(rdinputDict[key][0].split("-")[0])
        smallR = int(rdinputDict[key][0].split("-")[1])
        largeL = int(rdinputDict[key][1].split("-")[0])
        largeR = int(rdinputDict[key][1].split("-")[1])

        for k in rdinputDict.keys():
            if k != key and k not in tmprdList:
                xsmallL = int(rdinputDict[k][0].split("-")[0])
                xsmallR = int(rdinputDict[k][0].split("-")[1])
                xlargeL = int(rdinputDict[k][1].split("-")[0])
                xlargeR = int(rdinputDict[k][1].split("-")[1])

                if smallL <= xsmallL <= smallR or smallL <= xsmallR <= smallR or xsmallL <= smallL <= smallR <= xsmallR:
                    overlapLength = min(smallR,xsmallR) - max(smallL,xsmallL) +1
                    overrate1 = overlapLength / (smallR - smallL + 1)
                    overrate2 = overlapLength / (xsmallR - xsmallL + 1)
                    if overrate1 >= 0.8 and overrate2 >=0.8:
                        # 利用交集判断是否存在相同元素
                        setList=set(inputStrainDict[key]) & set(inputStrainDict[k])
                        setList=list(setList)
                        if setList !=[]:
                            tmprdList.append(k)
                            resultStrainDict[key] = list(set(inputStrainDict[key]) | set(inputStrainDict[k])) # 取并集
                            rsmallL = max(smallL,xsmallL)
                            rsmallR = min(smallR,xsmallR)
                            rlargeL= min(largeL,xlargeL)
                            rlargeR= max(largeR,xlargeR)
                            rdresultDict[key] = [str(rsmallL)+"-"+str(rsmallR),str(rlargeL)+"-"+str(rlargeR)]
                else:
                    continue


        if key not in resultStrainDict.keys():
            resultStrainDict[key] = inputStrainDict[key]
            rdresultDict[key] = rdinputDict[key]
    else:
        continue


for f in fileList:
    if f != "RD_regionx.txt":
        with open(outputfilefold+f.replace(".txt","")+"_merge.txt","w") as output:
            for rr in resultStrainDict.keys():
                if rr.split("_")[0][2:] == f.split("_")[0].replace(".",""):
                    output.write(rr+"\t")
                    for ii in resultStrainDict[rr]:
                        output.write(ii+"\t")
                    output.write("\n")

        with open(outputfilefold+"RD_regionx_merge.txt","w") as output:
            output.write(title+"\n")
            for r in rdresultDict.keys():
                output.write(r+"\t"+rdresultDict[r][0]+"\t"+rdresultDict[r][1]+"\n")

print("finished!!!!!!!")










