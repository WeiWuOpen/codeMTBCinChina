inputvcffold=r"F:\forStudy\studysite\RDworksite\mergeVcf\\"
inputuncoverbedfold=r"G:\aaaworkfilestore\TB\store_alluncover.bed\\"
inputLineageINFOFile=r"G:\aaaworksite\mtbc基因组数据总结\全部菌株clade对照add2.1合并4.5以及4.6789.txt"

outputFolder=r"F:\forStudy\studysite\RDworksite\step1\\"
outputfile=outputFolder+"RD_UncoverFiltered.txt"
outputCladelistFile=outputFolder+"allSampleCladeList.txt"
outputMissListFile=outputFolder+"missFileList.txt"

import numpy as np
import os
from tqdm import tqdm

# limitRate=0 # 不过滤
# limitRate=0.5
limitRate=0.75

if not os.path.exists(outputFolder):
    os.mkdir(outputFolder)


fileList=os.listdir(inputvcffold)
strainList=[]
for f in fileList:
    strainList.append(f.split(".")[0])

lineageDict={}
with open(inputLineageINFOFile,"r") as input:
    for ll in input:
        llx=ll.strip().split()
        lineageDict[llx[0]] = llx[1]

resultlist=[]
blankNum=0
wrongNum=0
for name in tqdm(strainList):
    vcfdict={}
    beddict={}
    with open(inputvcffold + name + ".merge.vcf","r") as inputvcf, open(inputuncoverbedfold + name + ".uncover.bed","r") as inputbed:
        for l in inputvcf:
            if l.strip() != "" and l.strip()[0] != "#"  and l.strip().split()[0] == "NC_000962.3": # 注意用于比对的参考序列要匹配
                lx=l.strip().split()
                # 只保留缺失（DEL）
                if lx[7].split(";")[3].split("=")[1] =="DEL":
                    vcfdict[lx[1]] = lx[7].split(";")[6].split("=")[1]
        for ll in inputbed:
            if ll.strip() != "":
                llx=ll.strip().split()
                beddict[llx[1]] = llx[2]

        for k in vcfdict.keys():
            overlaplist=[]
            overlaplengh = 0
            overlap = ""
            vcflength=int(vcfdict[k]) - int(k) +1
            for kk in beddict.keys():
                if int(k) <= int(kk) <= int(vcfdict[k]) or int(k) <= int(beddict[kk]) <= int(vcfdict[k]) or int(kk) <= int(k) <= int(vcfdict[k]) <= int(beddict[kk]):
                    overlaplist.append([max(int(k),int(kk))  ,  min(int(vcfdict[k]),int(beddict[kk]))])
            overlaplistUQ=[]
            for ilist in overlaplist:
                if ilist not in overlaplistUQ:
                    overlaplistUQ.append(ilist)
            if len(overlaplistUQ) >= 1:
                for o in overlaplistUQ:
                    overlap = overlap + str(o[0])  + "-" + str(o[1]) + "&"
                    overlaplengh = overlaplengh + (int(o[1]) - int(o[0])) +1
            if overlap !="":
                if overlap[-1] == "&":
                    overlap=overlap[:-1]
                if overlaplengh / vcflength >= limitRate:
                    resultlist.append([name, k, vcfdict[k], str(overlaplengh / vcflength), overlap])
                else:
                    wrongNum += 1
            else:
                blankNum+=1


print("No RD rate:")
print(blankNum/len(strainList))
print("NOT pass Rate:" )
print(wrongNum/len(strainList))

missList=[]
missDict={}
alllineageDict={}
for ls in lineageDict.keys():
    if lineageDict[ls] not in alllineageDict.keys():
        alllineageDict[lineageDict[ls]] = [ls]
    else:
        alllineageDict[lineageDict[ls]].append(ls)
    if ls not in strainList:
        missList.append(ls+"\t"+lineageDict[ls])
        if lineageDict[ls] not in missDict.keys():
            missDict[lineageDict[ls]] =[ls]
        else:
            missDict[lineageDict[ls]].append(ls)

print("##################")
print("missFileRate:")
for kk in missDict.keys():
    print(kk+": "+str(len(missDict[kk]))+"/"+str(len(alllineageDict[kk])))

title="Strain	StrainClade	StartPosition	EndPosition	Coverage	Cover_region"
with open(outputfile,"w") as output:
    output.write(title + "\n")
    for xx in resultlist:
        if xx[0] in lineageDict.keys():
            output.write(xx[0]+"\t"+lineageDict[xx[0]]+"\t"+xx[1]+"\t"+xx[2]+"\t"+xx[3]+"\t"+xx[4]+"\n")
        else:
            continue

with open(outputCladelistFile,"w") as output:
    for ss in strainList:
        if ss in lineageDict.keys():
            output.write(ss+"\t"+lineageDict[ss]+"\n")
        else:
            continue

with open(outputMissListFile,"w") as output:
    for yy in missList:
        output.write(yy+"\n")


print("finished!!!!")








