
inputFolder=r"F:\forStudy\studysite\RDworksite\step8\\"


import os

fileList=os.listdir(inputFolder)

for ff in fileList:
    if ".txt" in ff:
        with open()