inputfile=r"F:\forStudy\studysite\RDworksite\step1\RD_UncoverFiltered.txt"
outputfold=r"F:\forStudy\studysite\RDworksite\step2\\"

import copy
import numpy as np
import os
from tqdm import tqdm

# cladenamelist=["2.1","2.2a","2.2b","2.2c","2.2d","2.2e","4.2a","4.2b","4.2cn","4.4a","4.4cn","4.5","4.6789"]
cladenamelist=["2.1","2.2a","2.2b","2.2c","2.2d"]
# cladenamelist=["2.2e"]
# cladenamelist=["4.2a","4.2b","4.2cn","4.4a","4.4cn","4.5","4.6789"]

if os.path.exists(outputfold) !=True:
    os.mkdir(outputfold)

for ii in cladenamelist:
    exec('list%s=[]'%ii.replace(".",""))

with open(inputfile,"r") as input:
    for line in input:
        linex=line.strip().split()
        if linex[1] in cladenamelist:
            exec('list%s.append(line.strip())' %linex[1].replace(".", ""))

for i in cladenamelist:
    exec('dict_%s={}'%i.replace(".",""))
    for k in locals()['list{}'.format(i.replace(".",""))]:
        if k.split()[0] not in locals()['dict_{}'.format(i.replace(".",""))].keys():
            exec('dict_{}[k.split()[0]]=["_".join(k.split()[1:])]'.format(i.replace(".","")))
        else:
            exec('dict_{}[k.split()[0]].append("_".join(k.split()[1:]))'.format(i.replace(".","")))


print("###### step1 ######")
# nn=0
for i in tqdm(cladenamelist,desc="clade"):
    print(i+" start #############")
    # nn+=1
    # print(str(nn)+"/"+str(len(cladenamelist)))
    j=i.replace(".","")
    exec('RDlist_%s=[["-_-_1_2_-_-","-_-_1_2_-_-"]]' % j)
    # exec('RDlist_%s=[]' % j)
    for key in locals()['dict_{}'.format(j)].keys():
        exec('RDlistx_{}=copy.deepcopy(RDlist_{})'.format(j,j))
        for b in locals()['dict_{}'.format(j)][key]:
            for c in range(len(locals()['RDlistx_%s' % j])):
                r = locals()['RDlistx_%s' % j][c]
                if int(r[0].split("_")[2]) <= int(b.split("_")[1]) <= int(r[0].split("_")[3]) \
                        or int(r[0].split("_")[2]) <= int(b.split("_")[2]) <= int(r[0].split("_")[3]) \
                        or int(b.split("_")[1]) <= int(r[0].split("_")[2]) <= int(r[0].split("_")[3]) <= int(b.split("_")[2]):
                    exec('RDlist_%s[c].append(key + "_" + b)' % j)
                    oldlim1=copy.deepcopy(int(r[0].split("_")[2]))
                    newlim1=min(oldlim1,int(b.split("_")[1]))
                    oldlim2=copy.deepcopy(int(r[0].split("_")[3]))
                    newlim2=max(oldlim2,int(b.split("_")[2]))

                    commonnewlim1=max(oldlim1,int(b.split("_")[1]))
                    commonnewlim2=min(oldlim2,int(b.split("_")[2]))
                    exec('RDlist_%s[c][0]=str(commonnewlim1) +"_"+ str(commonnewlim2) + "_" + str(newlim1) +"_"+ str(newlim2) + "_-_-"' % j)
                else:
                    exec('xxx="_".join(RDlist_{}[-1][0].split("_")[0:4])'.format(j))
                    if key + "_" + b.split("_")[0] + "_" + b.split("_")[1] + "_" + b.split("_")[2] != xxx:
                        exec('RDlist_{}.append([key + "_" + b , key + "_" + b])'.format(j))

print("###### step2 ######")
# mm=0
for i in tqdm(cladenamelist,desc="clade"):
    print(i+" start #############")
    # mm+=1
    # print(str(mm) + "/" + str(len(cladenamelist)))
    j=i.replace(".","")
    exec('RDcombinelist_%s=[]' % j)
    exec('RDlist_work_%s=[]' % j)
    exec('RDdict_work_%s={}' % j)
    for p in locals()['RDlist_{}'.format(j)]:
        exec('RDlist_work_%s.append(p[0])' % j)
        exec('RDlist_work2_{}=np.unique(RDlist_work_{})'.format(j,j) )
    for pp in locals()['RDlist_work2_%s' % j]:
        exec('RDdict_work_%s[pp]=[0,0]' % j)
    for u in range(len(locals()['RDlist_{}'.format(j)])):
        exec('x=RDdict_work_{}[RDlist_{}[u][0]]'.format(j,j))
        exec('y=RDlist_{}[u][1:]'.format(j))
        if int(x[0]) < len(y):
            exec('RDdict_work_{}[RDlist_{}[u][0]][0] = len(RDlist_{}[u][1:])'.format(j,j,j))
            exec('RDdict_work_{}[RDlist_{}[u][0]][1] = u'.format(j, j))
    exec('del RDdict_work_{}["-_-_1_2_-_-"]'.format(j))
    exec('zlist=RDdict_work_{}.keys()'.format(j) )
    for key in zlist:
        exec('RDcombinelist_{}.append(RDlist_{}[RDdict_work_{}[key][1]])'.format(j,j,j))



with open(outputfold + "RD_regionx.txt", "a") as output:
    output.write("RD	Common region	Max region" + "\n")

for ii in cladenamelist:
    j=ii.replace(".","")
    with open(outputfold + ii + "_RD_filterUncover_cladeUnit.txt","w") as output:
        n=1
        for c in locals()['RDcombinelist_{}'.format(j)]:
                output.write("RD" + j + "_" + str(n) + "\t")
                n+=1
                for cc in c[1:]:
                    output.write("_".join([cc.split("_")[0],cc.split("_")[2],cc.split("_")[3],cc.split("_")[4],cc.split("_")[5]]) + "\t")
                output.write("\n")

    with open(outputfold + "RD_regionx.txt","a") as output:
        m=1
        for c in locals()['RDcombinelist_{}'.format(j)]:
                output.write("RD" + j + "_" + str(m) + "\t")
                m+=1
                if len(c) ==2:
                    output.write("-".join([c[0].split("_")[2],c[0].split("_")[3]]) + "\t" + "-".join([c[0].split("_")[2],c[0].split("_")[3]]) + "\t")
                    output.write("\n")
                else:
                    output.write("-".join([c[0].split("_")[0],c[0].split("_")[1]]) + "\t" + "-".join([c[0].split("_")[2],c[0].split("_")[3]]) + "\t")
                    output.write("\n")

print("finished")
