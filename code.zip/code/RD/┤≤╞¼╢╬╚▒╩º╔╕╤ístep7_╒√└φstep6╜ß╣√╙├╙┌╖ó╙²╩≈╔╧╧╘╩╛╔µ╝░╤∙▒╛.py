inputFile=r"F:\forStudy\studysite\RDworksite\step6\cladeRD_uniqueTESTresult_0.75overlap_去重复_中国枝有的.txt"
inputFolder=r"F:\forStudy\studysite\RDworksite\step2_2\\"
outputFolfer=r"F:\forStudy\studysite\RDworksite\step7\\"

import os
import numpy as np

if os.path.exists(outputFolfer) !=True:
    os.mkdir(outputFolfer)

fileList=os.listdir(inputFolder)
rdStrainDict={}
for f in fileList:
    if f[0:2] !="RD":
        with open(inputFolder+f,"r") as input:
            for l in input:
                lx=l.strip().split()
                rdStrainDict[lx[0]]=[]
                for x in lx[1:]:
                    rdStrainDict[lx[0]].append(x.split("_")[0])


tmpDict={}
with open(inputFile,"r") as input:
    for ll in input:
        llx=ll.strip().split()
        tmpDict[llx[0]] = llx[4:]

inputRDList=[]
for k in tmpDict.keys():
    inputRDList.append(k)
    if len(tmpDict[k]) >0:
        if tmpDict[k][0] !="unique":
            for r in tmpDict[k]:
                inputRDList.append(r.split("+")[0])

inputRDList=np.unique(inputRDList)

print(inputRDList)

for rd in inputRDList:
    with open(outputFolfer+rd+"_strain_list.txt","w") as output:
        for pp in rdStrainDict[rd]:
            output.write(pp+"\n")

    with open(outputFolfer + rd + "_strain_itol.txt", "w") as output:
        output.write("DATASET_COLORSTRIP"+"\n"+"SEPARATOR TAB"+"\n"+"DATASET_LABEL	HMCRD10"+"\n"+"DATA"+"\n")
        for pp in rdStrainDict[rd]:
            output.write(pp+"\t"+"#FF0000"+"\n")

