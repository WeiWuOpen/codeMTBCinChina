inputCladelistFile=r"F:\forStudy\studysite\RDworksite\step1\allSampleCladeList.txt" # 在step1中获得
## CRR104093	4.5c
## CRR104095	2.2b
## ......

inputStep2fold=r"F:\forStudy\studysite\RDworksite\step2_2\\"

outputfold=r"F:\forStudy\studysite\RDworksite\step3\\"
outputfile=outputfold + "RD_filterUncover_filterRD.txt"

# 过滤掉存在率低的RD
exlistRateLimit=0.1

from collections import Counter
import os

if os.path.exists(outputfold) !=True:
    os.mkdir(outputfold)


cladenamelist=["2.1","2.2a","2.2b","2.2c","2.2d","2.2e","4.2a","4.2b","4.2cn","4.4a","4.4cn","4.5","4.6789"]


cladenamelist2=[]
with open(inputCladelistFile,"r") as inputlist:
    for line in inputlist:
        linex=line.strip().split()
        if linex[1] in cladenamelist:
            cladenamelist2.append(linex[1])

cladenamedict=dict(Counter(cladenamelist2))


resultlist=[]
for i in cladenamelist:
    j=i.replace(".","")
    exec('RDdict_%s = {}'%j)
    with open(inputStep2fold + i + "_RD_filterUncover_cladeUnit_merge.txt","r") as input:
        for l in input:
            lx=l.strip().split()
            rate = int(len(lx[1:]))/int(cladenamedict[i])
            for ll in lx[1:]:
                resultlist.append("+".join([ll.split("_")[0],i,ll.split("_")[1],ll.split("_")[2],ll.split("_")[3],ll.split("_")[4],\
                                            lx[0],str(rate)]))

title="Strain	StrainClade	StartPosition	EndPosition	Coverage	Covered_region	RD	RD_presenceRate"
with open(outputfile,"w") as output:
    output.write(title + "\n")
    for ll in resultlist:
        if float(ll.split("+")[-1]) >= exlistRateLimit:
            output.write(ll.replace("+","\t") + "\n")





