# step4的输出文件
inputfile=r"F:\forStudy\studysite\RDworksite\step4\RD_filterUncover_filterRD_findRegion.txt"

outputfilefold=r"F:\forStudy\studysite\RDworksite\step5\\"


cladenamelist=["2.1","2.2a","2.2b","2.2c","2.2d","2.2e","4.2a","4.2b","4.2cn","4.4a","4.4cn","4.5","4.6789"]



RD_presenceRate_filterLowerlim=0.10
RD_presenceRate_filterUpperlim=1.0


from collections import Counter
import numpy as np
import os

if os.path.exists(outputfilefold) !=True:
    os.mkdir(outputfilefold)

if os.path.exists(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\") !=True:
    os.mkdir(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\")

inputlist=[]
with    open(inputfile,"r") as input:
    for line in input:
        if line.strip().split()[0] !="Strain":
            if  line.strip().split()[9] !="Outside": # 过滤掉不在功能区域内的
                if line.strip().split()[12] =="CDS" or line.strip().split()[12] =="promoter" \
                    or line.strip().split()[12] =="TRITSite": # 只保留与CDS和启动子、终止子有关的
                    inputlist.append(line.strip())
                else:
                    continue
            else:
                continue


for t in cladenamelist:
    j=t.replace(".","")
    exec('cladelist_%s=[]'%j)
    for i in inputlist:
        if i.split()[1] == t:
            exec('cladelist_%s.append(i.split()[0])'%j)
    exec('cladelist_unique_{}=list(np.unique(cladelist_{}))' .format(j,j))


inputlist_filter=[]
for l in inputlist:
    if RD_presenceRate_filterLowerlim <= float(l.split()[7]) <= RD_presenceRate_filterUpperlim:
        inputlist_filter.append(l)
RDnamelist=[]
for ll in inputlist_filter:
    RDnamelist.append(ll.split()[6].replace("-","_"))
RDnamelist=list(np.unique(RDnamelist))

for na in RDnamelist:
    exec('RDlist_{}=[]'.format(na))
    for b in inputlist_filter:
        if b.split()[6].replace("-","_") == na:
            exec('RDlist_{}.append(b.split()[0])'.format(na))
    exec('RDlist_{}=list(np.unique(RDlist_{}))'.format(na,na))


for i in cladenamelist:
    j=i.replace(".","")
    with open(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\" + i + "_RDmergedStrainList.txt","w" ) as output:
       for l in  locals()['cladelist_unique_{}'.format(j)]:
           output.write(l + "\n")
    with open(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\" + i + "_RDmergedStrainList_itol.txt","w" ) as output:
        output.write("TREE_COLORS" + "\n" + "SEPARATOR TAB" + "\n" + "DATA" + "\n" + "\n")
        for l in  locals()['cladelist_unique_{}'.format(j)]:
           output.write(l + "\t" + "range" + "\t" + "#696969" + "\n")


for ii in RDnamelist:
    with open(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\" + ii + "_StrainList.txt","w") as output:
        for ll in locals()['RDlist_{}'.format(ii)]:
            output.write(ll + "\n")
    with open(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\" + ii+ "_StrainList_itol.txt","w" ) as output:
        output.write("DATASET_COLORSTRIP"+ "\n" + "SEPARATOR TAB" + "\n" +"DATASET_LABEL	HMCRD10" + "\n" +"DATA" + "\n" + "\n")
        for ll in  locals()['RDlist_{}'.format(ii)]:
           output.write(ll+ "\t"  + "#FF0000" + "\n")
    with open(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\" + ii + "_StrainList_MISS.txt","w") as output:
        for ll in  locals()['cladelist_unique_{}'.format(ii.split("_")[0][2:])]:
            if ll not in locals()['RDlist_{}'.format(ii)]:
                output.write(ll + "\n")
    with open(outputfilefold+"\\"+str(RD_presenceRate_filterLowerlim)+"\\" + ii+ "_StrainList_MISS_itol.txt","w" ) as output:
        output.write("DATASET_COLORSTRIP"+ "\n" + "SEPARATOR TAB" + "\n" +"DATASET_LABEL	HMCRD10" + "\n" +"DATA" + "\n" + "\n")
        for ll in  locals()['cladelist_unique_{}'.format(ii.split("_")[0][2:])]:
            if ll not in locals()['RDlist_{}'.format(ii)]:
                output.write(ll+ "\t"  + "#00FFFF" + "\n")

