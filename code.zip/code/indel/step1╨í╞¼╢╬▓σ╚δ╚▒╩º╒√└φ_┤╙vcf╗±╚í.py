



cladeNameList=["4.2cnONLYchina","4.2bNOchina","2.2dONLYchina","2.2eNOchina","4.4cnONLYchina","4.4aNOchina","4.6789NOchina","4.5ONLYchina"]

cladeNameList=["allVcfStrain"]



inputvcffold=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\step1\\"


import os
from tqdm import tqdm


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)


for ii in cladeNameList:
    print(f"{ii} start #######")


    inputlistfile=r"G:\aaaworksite\mtbc基因组数据总结\\"+ii+".txt"


    strainlist=[]
    with open(inputlistfile,"r") as input:
        for l in input:
            strainlist.append(l.strip())


    vcfdict={}

    for j in tqdm(strainlist):
        linelist = []
        resultlist=[]
        with  open(inputvcffold + j +".recode.vcf" ,"r") as inputvcf:
            for line in inputvcf:
                if line.strip()[0] !="#" and line.strip().split()[6] == "PASS":
                    linelist.append(line.strip())
        for h in linelist:
            hx=h.split()
            if len(hx[3]) >1 and len(hx[4]) ==1:
                resultlist.append(str(int(hx[1])) +"_" + hx[3][1:] +"_"+ "deletion")
            elif len(hx[4]) >1 and len(hx[3]) ==1:
                resultlist.append(str(int(hx[1])) +"_" + hx[4][1:]  +"_"+ "insertion")


        title="Position(PreviousOneSite)	Seq	Type"
        with open(outputFolder+j+"_indel.txt","w") as output:
            output.write(title + "\n")
            for k in resultlist:
                output.write(k.replace("_","\t") + "\n")

print("finished")


