






inputFolder=r"F:\forStudy\studysite\indelWorksite\step4_2\\"

inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\\H37Rv.annotation_all.txt"


outputFolder=r"F:\forStudy\studysite\indelWorksite\step4_3\\"


regionList=["Rv0278c","Rv0279c","Rv0978c","Rv1452c","Rv2020c","Rv3426"]


import os
from tqdm import tqdm
from collections import Counter


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)


allRegionDict = {}
with open(inputAnnotationFile, "r") as input:
    for l in input:
        lx = l.strip().split()
        allRegionDict[lx[0]] = [int(lx[3]),int(lx[4])]


posList=[]
with open(inputFolder+"MeanStd_allIndelPos.txt", "r") as input:
    for l in input:
        lx=l.strip().split()
        if lx[0] !="Pos":
            posList.append(int(lx[0]))

for gg in regionList:
    inGenePosDict={}
    print(f"{gg} starting #######################")

    Llimit=allRegionDict[gg][0]
    Rlimit=allRegionDict[gg][1]
    for pos in posList:
        if Llimit - 1 <= pos <= Rlimit - 1:  # 位于目标区域内的，注意pos是先导碱基的位置
            if "c" not in gg: # 正链基因
                amidIndex = ( (pos-Llimit) // 3) +1 # 第几位氨基酸
                inGenePosDict[pos] = amidIndex
                del amidIndex
            else: # 反链基因
                amidIndex = (  (Rlimit-pos) // 3 ) +1 # 第几位氨基酸
                inGenePosDict[pos] = amidIndex
                del amidIndex


    with open(outputFolder+gg+"_commonPos_AApos.txt","w") as output:
        output.write("Pos"+"\t"+"AAPos"+"\n")
        for rr in inGenePosDict.keys():
            output.write(str(rr)+"\t"+str(inGenePosDict[rr])+"\n")

print("finished!!!!")




