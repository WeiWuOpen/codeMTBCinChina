

# inputFolder=r"F:\forStudy\studysite\indelWorksite\step2_2\\"
inputFolder=r"F:\forStudy\studysite\indelWorksite\step2_2_ramdomSmple\\"
# outputFolder=r"F:\forStudy\studysite\indelWorksite\step2_2_2\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\step2_2_2_ramdomSample\\"




# regionList=["Rv0278c","Rv0279c","Rv0978c","Rv1452c","Rv2020c","Rv3426"]
# regionList=["Rv0278c-inter-Rv0279c"]
regionList=["PE_PGRS17add","PE_PGRS28add"]

cladeNameList=["allL1","allL2","allL3","allL4","allL5","allL6","allFromAnimal"]

# cladeNameList=["2.2eNOchina","2.2dONLYchina","4.2bNOchina","4.2cnONLYchina","4.4aNOchina","4.4cnONLYchina","4.6789NOchina","4.5ONLYchina"]


import os
import pandas as pd


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)


for rr in regionList:
    data_framesList = []
    for cc in cladeNameList:
        # df = pd.read_csv(inputFolder+rr+"_"+cc+"_indel_StrainRate_in_clade.txt",sep="\t",header=None)
        df = pd.read_csv(inputFolder + rr + "_" + cc + "_indel_StrainRate_in_clade_randomSmple100_cycle1000.txt", sep="\t", header=None)
        data_framesList.append(df)
        del df

    combined_df=pd.concat(data_framesList,ignore_index=True,axis=1)  # 合并列
    print(combined_df)




    combined_df.to_csv(outputFolder+rr+"_L1-6-animal_indel_StrainRate_in_clade_combined.txt", sep="\t", index=False, header=False)
    # combined_df.to_csv(outputFolder+rr+"_CMC-NCMC__indel_StrainRate_in_clade_combined.txt", sep="\t", index=False, header=False)



print("finished!!!!!!")