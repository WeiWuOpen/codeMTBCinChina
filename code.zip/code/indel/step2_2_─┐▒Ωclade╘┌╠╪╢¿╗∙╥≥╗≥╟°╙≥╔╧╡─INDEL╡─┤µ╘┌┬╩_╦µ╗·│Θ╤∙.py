




inputFolder=r"F:\forStudy\studysite\indelWorksite\step1\\"

# inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\\H37Rv.annotation_all.txt"
inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\\H37Rv.annotation_special.txt"
# inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\\H37Rv.annotation_special2.txt"

inputSNPandINDELofH37RvFolder=r"F:\forStudy\studysite\indelWorksite\SNPandINDELofH37Rv\\"


outputFolder=r"F:\forStudy\studysite\indelWorksite\step2_2_ramdomSmple\\"


cladeNameList=["4.2cnONLYchina","4.2bNOchina","2.2dONLYchina","2.2eNOchina","4.4cnONLYchina","4.4aNOchina","4.6789NOchina","4.5ONLYchina"]

cladeNameList=["allL1","allL2","allL3","allL4","allL5","allL6"]
#
cladeNameList=["allFromAnimal"]

cladeNameList=["allVcfStrain"]





# regionList=["Rv0278c","Rv0279c","Rv0978c","Rv1452c","Rv2020c","Rv3426"]
regionList=["Rv0278c-inter-Rv0279c"]
# regionList=["PE_PGRS17add","PE_PGRS28add"]

randomSamNum=100 # 每次随机取样样本数,取样时不重复
cycleNum=1000 # 平行重复次数


import os
from tqdm import tqdm
from collections import Counter
import numpy as np


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)


allRegionDict = {}
with open(inputAnnotationFile, "r") as input:
    for l in input:
        lx = l.strip().split()
        allRegionDict[lx[0]] = [int(lx[3]),int(lx[4])]


for ii in cladeNameList:
    print(f"{ii} starting #######################")
    inputlistfile = r"G:\aaaworksite\mtbc基因组数据总结\\" + ii + ".txt"

    strainlist = []
    with open(inputlistfile, "r") as input:
        for l in input:
            strainlist.append(l.strip())


    for gg in regionList:
        print(f"{gg} starting #######################")

        Llimit=allRegionDict[gg][0]
        Rlimit=allRegionDict[gg][1]

        outputDict={}
        filterStrainList = []
        for ss in tqdm(strainlist):
            outputDict[ss]=[]
            try:
                with open(inputFolder+ss+"_indel.txt","r") as input:
                    for ll in input:
                        llx=ll.strip().split()
                        if llx[0] !="Position(PreviousOneSite)":
                            pos = int(llx[0])
                            if Llimit -1 <= pos <= Rlimit -1: # 位于目标区域内的，注意pos是先导碱基的位置
                                outputDict[ss].append(pos)

                filterStrainList.append(ss)
            except FileNotFoundError:
                print(ss + "_indel.txt is NOT found !!")
                del outputDict[ss]


        if (len(filterStrainList)) <= randomSamNum:
            print("after filter sample num <= randomSamNum !!!!!! ")
        else:
            cyResultDict={}
            for cy in tqdm(range(1, cycleNum + 1)):
                np.random.seed(179 * cy + 113)
                randomSamList = list(np.random.choice(filterStrainList, randomSamNum, replace=False)) # 单次取样不重复

                outputDict1={}
                for rs in randomSamList:
                    for pos in outputDict[rs]:
                        if pos not in outputDict1.keys():
                            outputDict1[pos] = 1
                        else:
                            outputDict1[pos] += 1
                outputDict2={}
                for kk in outputDict1.keys():
                    Rate= outputDict1[kk] / randomSamNum
                    if kk not in cyResultDict.keys():
                        cyResultDict[kk]=[Rate]
                    else:
                        cyResultDict[kk].append(Rate)
                    del Rate
            cyResultDict2={}
            for pp in cyResultDict.keys():
                if len(cyResultDict[pp]) < cycleNum:
                    addNum=cycleNum-len(cyResultDict[pp])
                    addList=[0.0] * addNum
                    cyResultDict2[pp]=cyResultDict[pp] + addList
                    del addList
                elif len(cyResultDict[pp]) == cycleNum:
                    cyResultDict2[pp] = cyResultDict[pp]
                else:
                    print("wrong!!!!!!!")

            MeanStdResultDict={}
            for p in cyResultDict2.keys():
                mean=np.mean(cyResultDict2[p])
                std=np.std(cyResultDict2[p])
                MeanStdResultDict[p]=str(mean)+"\t"+str(std)
                del mean
                del std




            with open(outputFolder+gg+"_"+ii+"_indel_StrainRate_in_clade_randomSmple"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","w") as output:
                output.write("Pos"+"\t"+"Mean_Rate_in_"+ii+"\t"+"Std_Rate_in_"+ii+"\n")
                for rr in sorted(MeanStdResultDict.keys()):
                    output.write(str(rr)+"\t"+str(MeanStdResultDict[rr])+"\n")

print("finished!!!!")




