



inputFolder=r"F:\forStudy\studysite\indelWorksite\差值SNPandINDEL_density_byRegion\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\差值Mean&Std_SNPandINDEL_density_byRegion\\"



import os
from tqdm import tqdm
import numpy as np


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)



inputDict={}
fileList=os.listdir(inputFolder)

print(fileList)
fileNum=0
for ff in fileList:
    if "_密度的差值_byRegion.txt" in ff:
        fileNum+=1
        with open(inputFolder+ff,"r") as input:
            for ll in input:
                llx=ll.strip().split()
                if llx[0] !="Pos":
                    key= int(llx[0])
                    if key not in inputDict.keys():
                        inputDict[key]=[float(llx[1])]
                    else:
                        inputDict[key].append(float(llx[1]))


resultDict={}
for kk in inputDict.keys():
    if len(inputDict[kk]) == fileNum:
        mean=np.mean(inputDict[kk])
        std=np.std(inputDict[kk])
        resultDict[kk]=str(mean)+"\t"+str(std)
        del mean
        del std
    else:
        print(f"pos: {kk} NOT in some File !!!!!")
        tmpList=inputDict[kk]
        while len(tmpList)<  fileNum: # 补齐
            tmpList.append(0.0)
        mean = np.mean(tmpList)
        std = np.std(tmpList)
        resultDict[kk] = str(mean) + "\t" + str(std)
        del mean
        del std
        del tmpList



with open(outputFolder+"MeanStd_allIndelPos_byRegion.txt","w") as output:
    output.write("Pos"+"\t"+"Mean_difOFdensity_byRegion"+"\t"+"Std_difOFdensity_byRegion"+"\n")
    for rr in sorted(resultDict.keys()):
        output.write(str(rr)+"\t"+resultDict[rr]+"\n")



print("finished!!!!")




