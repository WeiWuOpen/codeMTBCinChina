


inputVCFFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"
inputrefseqFile = r"G:\aaaworkfilestore\TB\TB_annatationfile\refseq\H37Rv_r.fasta"

stepLength = 10000

outputFolder1=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_density_step" +str(stepLength)  + "\\"
outputFolder2=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_ableNumRate_step" +str(stepLength)  + "\\"



# cladeNameList=["4.2cnONLYchina","4.2bNOchina","4.4cnONLYchina","4.4aNOchina"]
# cladeNameList=["4.6789NOchina","2.2eNOchina"]
# cladeNameList=["4.5ONLYchina","2.2dONLYchina"]
# cladeNameList=["allVcfStrain"]


cladeNameList=["allFromAnimal"]
# cladeNameList=["M.canetti"]
# cladeNameList=["aDNA_p_3"]
# cladeNameList=["aDNA_L4_3"]

# cladeNameList=["allL1","allL2","allL3","allL4","allL5","allL6","allL7","allL8","allL9"]


stepLength = 10000


import os
from tqdm import tqdm
from collections import Counter
import numpy as np


if os.path.exists(outputFolder1) !=True:
    os.mkdir(outputFolder1)

if os.path.exists(outputFolder2) !=True:
    os.mkdir(outputFolder2)


refseqdict = {}
with open(inputrefseqFile, "r") as input:
    for l in input:
        if l.strip()[0] != ">":
            refseq = list(l.strip())
for i in range(1, len(refseq) + 1):
    refseqdict[int(i)] = refseq[i - 1]
refLength=len(refseqdict)


#######################################################################
def cal_density(inputList, refLength, stepLength, sampleNum):
    countPosDict = dict(Counter(inputList))
    sortedinputList = sorted(countPosDict.keys())
    startIndex = 0
    resultDict = {}
    for i in range(1, refLength + 1, stepLength):
        if min(i + stepLength, refLength + 1) != refLength + 1:
            startPos = i
            midPos = (i + i + stepLength) / 2 - 1
            endPos = i + stepLength - 1
        else:
            startPos = i
            midPos = (i + refLength) / 2  # 最后一个不满的区间
            endPos = refLength
        indelNum = 0
        for cc in range(startIndex, len(sortedinputList)):
            if i <= sortedinputList[cc] < i + stepLength:
                indelNum += countPosDict[sortedinputList[cc]]
            else:
                startIndex = cc
                break

        resultDict[startPos] = (indelNum / stepLength) / sampleNum  # 在step长度区间内平均每个样本每个碱基indel发生率
        resultDict[midPos] = (indelNum / stepLength) / sampleNum  # 在step长度区间内平均每个样本每个碱基indel发生率
        resultDict[endPos] = (indelNum / stepLength) / sampleNum  # 在step长度区间内平均每个样本每个碱基indel发生率

        del startPos
        del midPos
        del endPos
        del indelNum
    return resultDict


def cal_diversity(inputList, refLength, stepLength):
    sortedUniqueinputList = sorted(list(np.unique(inputList)))
    startIndex = 0
    resultDict = {}
    for i in range(1, refLength + 1, stepLength):
        if min(i + stepLength, refLength + 1) != refLength + 1:
            startPos = i
            midPos = (i + i + stepLength) / 2 - 1
            endPos = i + stepLength - 1
        else:
            startPos = i
            midPos = (i + refLength) / 2  # 最后一个不满的区间
            endPos = refLength
        indelNum = 0
        for cc in range(startIndex, len(sortedUniqueinputList)):
            if i <= sortedUniqueinputList[cc] < i + stepLength:
                indelNum += 1
            else:
                startIndex = cc
                break

        resultDict[startPos] = indelNum / stepLength
        resultDict[midPos] = indelNum / stepLength
        resultDict[endPos] = indelNum / stepLength

        del startPos
        del midPos
        del endPos
        del indelNum

    return resultDict


##############################################################################


for cladeName in cladeNameList:
    print(cladeName +" is working #######")
    inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"
    strainlist=[]
    strainlist = []
    with open(inputlistFile, "r") as input:
        for ee in input:
            strainlist.append(ee.strip())
    strainNum = len(strainlist)


    posList=[]
    poslistSNP=[]
    poslistINDEL=[]
    for ss in tqdm(strainlist):
        try:
            with open(inputVCFFolder+ss+".recode.vcf","r") as input:
                for ll in input:
                    llx=ll.strip().split()
                    if llx[0] != "#":
                        if llx[0] =="NC_000962.3" and llx[6] =="PASS":
                            posList.append(int(llx[1]))
                            if len(llx[3]) ==1 and len(llx[4]) ==1: # SNP
                                poslistSNP.append(int(llx[1]))
                            else:
                                poslistINDEL.append(int(llx[1]))
        except FileNotFoundError:
            print(ss+".recode.vcf is NOT found !!")



    resultDict_all=cal_density(posList,refLength,stepLength,strainNum)
    with open(outputFolder1+cladeName+"_SNP&indel_density_"+str(stepLength)+".txt","w") as output:
        output.write("Pos"+"\t"+cladeName+"_SNP&INDEL_density_"+str(stepLength)+"\n")
        for rr in sorted(resultDict_all.keys()):
            output.write(str(int(rr))+"\t"+str(resultDict_all[rr])+"\n")

    resultDict_snp=cal_density(poslistSNP,refLength,stepLength,strainNum)
    with open(outputFolder1+cladeName+"_SNP_density_"+str(stepLength)+".txt","w") as output:
        output.write("Pos"+"\t"+cladeName+"_SNP_density_"+str(stepLength)+"\n")
        for rr in sorted(resultDict_snp.keys()):
            output.write(str(int(rr))+"\t"+str(resultDict_snp[rr])+"\n")

    resultDict_indel=cal_density(poslistINDEL,refLength,stepLength,strainNum)
    with open(outputFolder1+cladeName+"_indel_density_"+str(stepLength)+".txt","w") as output:
        output.write("Pos"+"\t"+cladeName+"_INDEL_density_"+str(stepLength)+"\n")
        for rr in sorted(resultDict_indel.keys()):
            output.write(str(int(rr))+"\t"+str(resultDict_indel[rr])+"\n")


    del resultDict_all
    del resultDict_indel
    del resultDict_snp



    resultDict_all=cal_diversity(posList,refLength,stepLength)
    with open(outputFolder2+cladeName+"_SNP&indel_ableNumRate_"+str(stepLength)+".txt","w") as output:
        output.write("Pos"+"\t"+cladeName+"_SNP&INDEL_ableNumRate_"+cladeName+"_"+str(stepLength)+"\n")
        for rr in sorted(resultDict_all.keys()):
            output.write(str(int(rr))+"\t"+str(resultDict_all[rr])+"\n")

    resultDict_snp=cal_diversity(poslistSNP,refLength,stepLength)
    with open(outputFolder2+cladeName+"_SNP_ableNumRate_"+str(stepLength)+".txt","w") as output:
        output.write("Pos"+"\t"+cladeName+"_SNP_ableNumRate_"+cladeName+"_"+str(stepLength)+"\n")
        for rr in sorted(resultDict_snp.keys()):
            output.write(str(int(rr))+"\t"+str(resultDict_snp[rr])+"\n")

    resultDict_indel=cal_diversity(poslistINDEL,refLength,stepLength)
    with open(outputFolder2+cladeName+"_indel_ableNumRate_"+str(stepLength)+".txt","w") as output:
        output.write("Pos"+"\t"+cladeName+"_INDEL_ableNumRate_"+cladeName+"_"+str(stepLength)+"_"+cladeName+"\n")
        for rr in sorted(resultDict_indel.keys()):
            output.write(str(int(rr))+"\t"+str(resultDict_indel[rr])+"\n")

    del resultDict_all
    del resultDict_indel
    del resultDict_snp



print("finished!!!!")




