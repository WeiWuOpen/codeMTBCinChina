
inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\\H37Rv.annotation_all.txt"
inputrefseqFile = r"G:\aaaworkfilestore\TB\TB_annatationfile\refseq\H37Rv_r.fasta"
inputVcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"

inputHTfile=r"F:\forStudy\studysite\indelWorksite\ht\ht_h37rv.txt"

outputFolder=r"F:\forStudy\studysite\全基因组的熵等性质\\"



cladeNameList=["4.2cnONLYchina","4.2bNOchina","4.4cnONLYchina","4.4aNOchina"]
cladeNameList = ["4.6789NOchina", "2.2eNOchina"]
cladeNameList=["4.5ONLYchina","2.2dONLYchina"]
#
#
#
# cladeNameList=["allVcfStrain"]



import os
import numpy as np
import copy
import math
from tqdm import tqdm
from collections import Counter
import bisect


os.makedirs(outputFolder, exist_ok=True)


refseqdict = {}
with open(inputrefseqFile, "r") as input:
    for l in input:
        if l.strip()[0] != ">":
            refseq = list(l.strip())
for i in range(1, len(refseq) + 1):
    refseqdict[int(i)] = refseq[i - 1]
wholeGenomeLength=len(refseqdict)


allCDSDict = {}
with open(inputAnnotationFile, "r") as input:
    for l in input:
        lx = l.strip().split()
        if lx[2] =="CDS":
            allCDSDict[int(lx[3])] = [lx[0],int(lx[4])]




allCutDict=copy.deepcopy(allCDSDict)

cdsPosList=sorted(allCDSDict.keys())
for ci in range(0,len(cdsPosList)):
    if ci != len(cdsPosList)-1: # 最后一个之前
        sp=cdsPosList[ci]
        ep=allCDSDict[sp][1]
        nextsp=cdsPosList[ci+1]

        gapLength = nextsp - ep -1
        if gapLength >= 100: # gap长度太短的不要了
            name=allCDSDict[nextsp][0]+"_upGap"
            gapSp=ep+1
            gapEp=nextsp -1
            allCutDict[gapSp]=[name,gapEp]
            del gapEp
            del gapSp
            del gapLength
            del name
    else:
        sp = cdsPosList[ci]
        gapSp= sp +1
        gapEp=wholeGenomeLength
        name="finalGap"
        allCutDict[gapSp] = [name, gapEp]
        del gapEp
        del gapSp
        del name

# print(allCutDict)


##############################################

htDict = {}
with open(inputHTfile, "r") as input:
    for l in input:
        lx = l.strip().split()
        htDict[int(lx[0])] = [int(lx[2]), int(lx[3])]  # {startPos:[startPos,endPos]}

htPosList = sorted(htDict.keys())



# 信息熵 #############################################
def cal_IE(startPos, endPos, refseqdict):
    numA = 0
    numT = 0
    numC = 0
    numG = 0
    for p in range(startPos, endPos + 1):
        if refseqdict[p] == "A":
            numA += 1
        elif refseqdict[p] == "T":
            numT += 1
        elif refseqdict[p] == "C":
            numC += 1
        elif refseqdict[p] == "G":
            numG += 1
        else:
            print(refseqdict[p])
        pA = numA / (endPos - startPos + 1)
        pT = numT / (endPos - startPos + 1)
        pC = numC / (endPos - startPos + 1)
        pG = numG / (endPos - startPos + 1)
    e = math.e
    IES = -pA * math.log(pA, e) - pT * math.log(pT, e) - pC * math.log(pC, e) - pG * math.log(pG, e)
    return str(IES)


######################################################


#########################################################################
# indel和SNP密度 ########################################
def cal_diversity(sortedUniqueinputListSNP, sortedUniqueinputListINDEL,startPos, endPos, startIndexSNP, startIndexINDEL):
    snpNum=0
    indelNum=0
    for ii in range(startIndexSNP,len(sortedUniqueinputListSNP)):
        pos = sortedUniqueinputListSNP[ii]
        if pos < startPos:
            continue
        elif startPos <= pos <= endPos:
            snpNum +=1
            continue
        else:
            startIndexSNP = ii
            break
    for iii in range(startIndexINDEL,len(sortedUniqueinputListINDEL)):
        pos = sortedUniqueinputListINDEL[iii]
        if pos < startPos:
            continue
        elif startPos <= pos <= endPos:
            indelNum +=1
            continue
        else:
            startIndexINDEL = iii
            break

    dy_snp = snpNum / (endPos - startPos + 1)
    dy_indel = indelNum / (endPos - startPos + 1)
    dy_all = (snpNum + indelNum) / (endPos - startPos + 1)

    return [str(dy_all), str(dy_snp), str(dy_indel), startIndexSNP,startIndexINDEL]


###############################################################


############################################################################
def cal_density(sortedUniqueinputListSNP, sortedUniqueinputListINDEL, countPosDictSNP, countPosDictINDEL,startPos, endPos, startIndexSNP, startIndexINDEL, sampleNum):

    indelNum = 0
    snpNum = 0
    for ii in range(startIndexSNP, len(sortedUniqueinputListSNP)):
        pos = sortedUniqueinputListSNP[ii]
        if pos < startPos:
            continue
        elif startPos <= pos <= endPos:
            snpNum += countPosDictSNP[pos]
            continue
        else:
            startIndexSNP = ii
            break
    for iii in range(startIndexINDEL, len(sortedUniqueinputListINDEL)):
        pos = sortedUniqueinputListINDEL[iii]
        if pos < startPos:
            continue
        if startPos <= pos <= endPos:
            indelNum += countPosDictINDEL[pos]
            continue
        else:
            startIndexINDEL = iii
            break

    de_indel = indelNum / (endPos - startPos + 1) / sampleNum  # 平均每个样本每个碱基的indel发生率
    de_snp = snpNum / (endPos - startPos + 1) / sampleNum  # 平均每个样本每个碱基的snp发生率
    de_all = (indelNum + snpNum) / (endPos - startPos + 1) / sampleNum  # 平均每个样本每个碱基的snp&indel发生率

    return [str(de_all), str(de_snp), str(de_indel), startIndexSNP,startIndexINDEL]


##############################################################
##############################################################

# 计算GC含量 #########################
def cal_GC(startPos, endPos, refseqdict):
    numA = 0
    numT = 0
    numC = 0
    numG = 0
    for p in range(startPos, endPos + 1):
        if refseqdict[p] == "A":
            numA += 1
        elif refseqdict[p] == "T":
            numT += 1
        elif refseqdict[p] == "C":
            numC += 1
        elif refseqdict[p] == "G":
            numG += 1
        else:
            print(refseqdict[p])
    numAll = numA + numT + numC + numG
    numGC = numG + numC
    rateGC = numGC / numAll
    return str(rateGC)


###############################################


# 计算HT序列的比例和数量 ###################################
def cal_HT(htDict,htPosList, startPos, endPos,startIndexHT):
    htNum = 0
    htLength = 0

    for ii in range(startIndexHT,len(htPosList)):
        pos = htPosList[ii]
        if pos < startPos:
            continue
        elif startPos <= pos <= endPos:
            htNum +=1
            htLength += htDict[pos][1] -htDict[pos][0] +1
            continue
        else:
            startIndexHT = ii
            break

    htNumRate = htNum / (endPos - startPos + 1)
    htLengthRate = htLength / (endPos - startPos + 1)

    return [str(htNumRate), str(htLengthRate),startIndexHT]


###################################################


for cladeName in cladeNameList:
    print(cladeName +" is working #######")
    inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"

    # vcf中的snp和indel  ############################################
    strainlist=[]
    with open(inputlistFile,"r") as input:
        for ee in input:
            strainlist.append(ee.strip())
    strainNum=len(strainlist)

    poslistSNP=[]
    poslistINDEL=[]
    for ss in tqdm(strainlist):
        try:
            with open(inputVcfFolder+ss+".recode.vcf","r") as input:
                for ll in input:
                    llx=ll.strip().split()
                    if llx[0] != "#":
                        if llx[0] =="NC_000962.3" and llx[6] =="PASS":
                            if len(llx[3]) ==1 and len(llx[4]) ==1: # SNP
                                poslistSNP.append(int(llx[1]))
                            else:
                                poslistINDEL.append(int(llx[1]))
        except FileNotFoundError:
            print(ss+".recode.vcf is NOT found !!")
    sortedUniqueinputListSNP = sorted(list(np.unique(poslistSNP)))
    sortedUniqueinputListINDEL = sorted(list(np.unique(poslistINDEL)))
    countPosDictSNP = dict(Counter(poslistSNP))
    countPosDictINDEL = dict(Counter(poslistINDEL))
    ###############################################################

    resultDict={}
    startIndexSNP_di=0
    startIndexINDEL_di = 0
    startIndexSNP_de=0
    startIndexINDEL_de = 0
    startIndexHT=0

    for cc in tqdm(sorted(allCutDict.keys())): # key必须要从小到大排序
        name=allCutDict[cc][0]
        startPos=cc
        endPos=allCutDict[cc][1]
        midPos = str( int((startPos+endPos) / 2) )
        ieResult=cal_IE(startPos,endPos,refseqdict)

        diResult=cal_diversity(sortedUniqueinputListSNP, sortedUniqueinputListINDEL,startPos, endPos, startIndexSNP_di, startIndexINDEL_di)
        diResultList=diResult[0:3]
        startIndexSNP_di = diResult[3]
        startIndexINDEL_di = diResult[4]

        deResult = cal_density(sortedUniqueinputListSNP, sortedUniqueinputListINDEL,countPosDictSNP,countPosDictINDEL, startPos, endPos,startIndexSNP_de, startIndexINDEL_de,strainNum)
        deResultList=deResult[0:3]
        startIndexSNP_de = deResult[3]
        startIndexINDEL_de = deResult[4]
        GCresult=cal_GC(startPos,endPos,refseqdict)
        htResult=cal_HT(htDict, htPosList, startPos, endPos, startIndexHT)
        htResultList=htResult[0:2]
        startIndexHT=htResult[2]

        del startPos
        del endPos

        resultDict[name]=[midPos]+[ieResult] + diResultList + deResultList + [GCresult] + htResultList
        del midPos

    with open(outputFolder+cladeName+"_result.txt","w") as output:
        output.write("Region	Type	midPos"+"\t"+f"Entory_{cladeName}	diALL_{cladeName}	diSNP_{cladeName}	diINDEL_{cladeName}	deALL_{cladeName}	deSNP_{cladeName}	deINDEL_{cladeName}	GCrate_{cladeName}	htNumRate_{cladeName}	htLengthRate_{cladeName}"+"\n")
        for rr in resultDict.keys():
            if "Gap" in rr:
                output.write(rr+"\t"+"outCDS"+"\t"+"\t".join(resultDict[rr])+"\n")
            else:
                output.write(rr +"\t"+"CDS" + "\t" + "\t".join(resultDict[rr]) + "\n")

print("finished!!!!!!")



























