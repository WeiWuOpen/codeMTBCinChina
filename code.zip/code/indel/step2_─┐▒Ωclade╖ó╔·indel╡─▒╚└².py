


inputFolder=r"F:\forStudy\studysite\indelWorksite\step1\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\step2\\"

inputSNPandINDELofH37RvFolder=r"F:\forStudy\studysite\indelWorksite\SNPandINDELofH37Rv\\"




cladeNameList=["4.2cnONLYchina","4.2bNOchina","2.2dONLYchina","2.2eNOchina","4.4cnONLYchina","4.4aNOchina","4.6789NOchina","4.5ONLYchina"]

# cladeNameList=["allL1","allL2","allL3","allL4","allL5","allL6","allL7","allL8","allL9"]

# cladeNameList=["allFromAnimal"]

# cladeNameList=["allVcfStrain"]



import os
from tqdm import tqdm
from collections import Counter


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)


indelOFrefList=[]
with open(inputSNPandINDELofH37RvFolder+"INDELinH37Rv.txt","r") as input:
    for ll in input:
        llx=ll.strip().split()
        if llx[0] !="Pos":
            indelOFrefList.append(int(llx[0]))
indelOFrefSet=set(indelOFrefList)

# print(len(indelOFrefSet))


for ii in cladeNameList:
    print(f"{ii} start ############################")
    inputlistfile = r"G:\aaaworksite\mtbc基因组数据总结\\" + ii + ".txt"
    strainlist = []
    with open(inputlistfile, "r") as input:
        for l in input:
            strainlist.append(l.strip())



    outputDict1={}
    filterStrainList=[]

    for ss in tqdm(strainlist):
        try:
            with open(inputFolder+ss+"_indel.txt","r") as input:
                for ll in input:
                    llx=ll.strip().split()
                    if llx[0] !="Position(PreviousOneSite)":
                        key = int(llx[0]) # 同一个位点的不同indel视为一个
                        if key not in indelOFrefSet: # 排除是参考序列自身的INDEL
                            if key not in outputDict1.keys():
                                outputDict1[key] =  1
                            else:
                                outputDict1[key] +=  1
            filterStrainList.append(ss)
        except FileNotFoundError:
            print(ss + "_indel.txt is NOT found !!")


    print(f"{len(filterStrainList)} / {len(strainlist)}  sample exist!!!")
    strainNum=len(filterStrainList)

    outputDict2={}
    for kk in outputDict1.keys():
        Rate= outputDict1[kk] / strainNum
        outputDict2[kk] = Rate
        del Rate

    with open(outputFolder+ii+"_indel_rate.txt","w") as output:
        output.write("Pos"+"\t"+ii+"_sampleRate_in_clade"+"\n")
        for rr in sorted(outputDict2.keys()):
            output.write(str(rr)+"\t"+str(outputDict2[rr])+"\n")

print("finished!!!!")




