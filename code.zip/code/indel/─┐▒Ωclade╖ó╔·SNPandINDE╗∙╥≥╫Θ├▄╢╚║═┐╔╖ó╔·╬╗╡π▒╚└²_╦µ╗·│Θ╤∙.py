


inputVCFFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"
inputrefseqFile = r"G:\aaaworkfilestore\TB\TB_annatationfile\refseq\H37Rv_r.fasta"


# cladeNameList=["4.2cnONLYchina","4.2bNOchina","4.4cnONLYchina","4.4aNOchina"]
# cladeNameList=["4.6789NOchina","2.2eNOchina"]
# cladeNameList=["4.5ONLYchina","2.2dONLYchina"]
# cladeNameList=["allVcfStrain"]

cladeNameList=["allL1","allL2","allL3","allL4"]

cladeNameList=["allVcfStrain"]




stepLength = 10000
randomSamNum=200 # 每次随机取样样本数,取样时不重复
cycleNum=100 # 平行重复次数


outputFolder1=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_density_random_step" + str(stepLength)+"\\"
outputFolder2=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_ableNumRate_random_step" + str(stepLength)+"\\"

import os
from tqdm import tqdm
from collections import Counter
import numpy as np


os.makedirs(outputFolder1, exist_ok=True)
os.makedirs(outputFolder2, exist_ok=True)

refseqdict = {}
with open(inputrefseqFile, "r") as input:
    for l in input:
        if l.strip()[0] != ">":
            refseq = list(l.strip())
for i in range(1, len(refseq) + 1):
    refseqdict[int(i)] = refseq[i - 1]
refLength=len(refseqdict)


#######################################################################
def cal_density(inputList, refLength, stepLength, sampleNum):
    countPosDict = dict(Counter(inputList))
    sortedinputList = sorted(countPosDict.keys())
    startIndex = 0
    resultDict = {}
    for i in range(1, refLength + 1, stepLength):
        if min(i + stepLength, refLength + 1) != refLength + 1:
            startPos = i
            midPos = (i + i + stepLength) / 2 - 1
            endPos = i + stepLength - 1
        else:
            startPos = i
            midPos = (i + refLength) / 2  # 最后一个不满的区间
            endPos = refLength
        indelNum = 0
        for cc in range(startIndex, len(sortedinputList)):
            if i <= sortedinputList[cc] < i + stepLength:
                indelNum += countPosDict[sortedinputList[cc]]
            else:
                startIndex = cc
                break

        resultDict[startPos] = (indelNum / stepLength) / sampleNum  # 在step长度区间内平均每个样本每个碱基indel发生率
        resultDict[midPos] = (indelNum / stepLength) / sampleNum  # 在step长度区间内平均每个样本每个碱基indel发生率
        resultDict[endPos] = (indelNum / stepLength) / sampleNum  # 在step长度区间内平均每个样本每个碱基indel发生率

        del startPos
        del midPos
        del endPos
        del indelNum
    return resultDict


def cal_diversity(inputList, refLength, stepLength):
    sortedUniqueinputList = sorted(list(np.unique(inputList)))
    startIndex = 0
    resultDict = {}
    for i in range(1, refLength + 1, stepLength):
        if min(i + stepLength, refLength + 1) != refLength + 1:
            startPos = i
            midPos = (i + i + stepLength) / 2 - 1
            endPos = i + stepLength - 1
        else:
            startPos = i
            midPos = (i + refLength) / 2  # 最后一个不满的区间
            endPos = refLength
        indelNum = 0
        for cc in range(startIndex, len(sortedUniqueinputList)):
            if i <= sortedUniqueinputList[cc] < i + stepLength:
                indelNum += 1
            else:
                startIndex = cc
                break

        resultDict[startPos] = indelNum / stepLength
        resultDict[midPos] = indelNum / stepLength
        resultDict[endPos] = indelNum / stepLength

        del startPos
        del midPos
        del endPos
        del indelNum

    return resultDict
##############################################################################
def output_to_file(inputresultDict,outputFile,type):
    with open(outputFile,"w") as output:
        if "density" in outputFile:
            output.write("Pos"+"\t"+"Mean_"+type+"_density"+"\t"+"Std_"+type+"_density"+"\n")
        elif "ableNumRate" in outputFile:
            output.write("Pos" + "\t" + "Mean_" + type + "_ableNumRate" + "\t" + "Std_" + type + "_ableNum" + "\n")
        for rr in inputresultDict.keys():
            output.write(str(rr) + "\t"+ str(inputresultDict[rr][0]) +"\t"+ str(inputresultDict[rr][1]) + "\n")

###################################################################################



for cladeName in cladeNameList:
    print(cladeName +" is working #######")
    inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"
    strainlist = []
    with open(inputlistFile, "r") as input:
        for ee in input:
            strainlist.append(ee.strip())
    strainNum = len(strainlist)

    print(f"All sample Num: {strainNum}")
    print(f"random sampling Num: {randomSamNum}")

    posDict={}
    n=0
    filterStrainlist=[]
    for ss in tqdm(strainlist):
        n+=1
        posList = []
        poslistSNP = []
        poslistINDEL = []

        try:
            with open(inputVCFFolder+ss+".recode.vcf","r") as input:
                for ll in input:
                    llx=ll.strip().split()
                    if llx[0] != "#":
                        if llx[0] =="NC_000962.3" and llx[6] =="PASS":
                            posList.append(int(llx[1]))
                            if len(llx[3]) ==1 and len(llx[4]) ==1: # SNP
                                poslistSNP.append(int(llx[1]))
                            else:
                                poslistINDEL.append(int(llx[1])) # INDEL

            posDict[ss] = [posList, poslistSNP, poslistINDEL]
            filterStrainlist.append(ss)
            del posList
            del poslistSNP
            del poslistINDEL

        except FileNotFoundError:
            print(ss+".recode.vcf is NOT found !!")


    filterStrainNum=len(filterStrainlist)
    print(f"{filterStrainNum} / {strainNum}  sample exist !!!!!")


    #  抽样cycle ########
    cyResultDict={}
    for cy in tqdm(range(1,cycleNum+1)):
        np.random.seed(139*cy+713)
        randomSamList=list(np.random.choice(filterStrainlist,randomSamNum,replace=False))
        ranALLposList=[]
        ranSNPposList=[]
        ranINDELposList=[]
        for sam in randomSamList:
            ranALLposList = ranALLposList + posDict[sam][0]
            ranSNPposList = ranSNPposList + posDict[sam][1]
            ranINDELposList = ranINDELposList + posDict[sam][2]

        allresultDict_d=cal_density(ranALLposList, refLength, stepLength,randomSamNum)
        snpresultDict_d=cal_density(ranSNPposList, refLength, stepLength,randomSamNum)
        indelresultDict_d=cal_density(ranINDELposList, refLength, stepLength,randomSamNum)

        allresultDict_a=cal_diversity(ranALLposList, refLength, stepLength)
        snpresultDict_a=cal_diversity(ranSNPposList, refLength, stepLength)
        indelresultDict_a=cal_diversity(ranINDELposList, refLength, stepLength)

        cyResultDict[cy] = [allresultDict_d,snpresultDict_d,indelresultDict_d,allresultDict_a,snpresultDict_a,indelresultDict_a]


    cyallresultDict_d={}
    cysnpresultDict_d ={}
    cyindelresultDict_d ={}
    cyallresultDict_a ={}
    cysnpresultDict_a ={}
    cyindelresultDict_a ={}

    def tmpF(inputDict,outputDict):
        for pp in inputDict.keys():
            if pp not in outputDict.keys():
                outputDict[pp] = [inputDict[pp]]
            else:
                outputDict[pp].append(inputDict[pp])
        return outputDict


    for cy in cyResultDict.keys():
        cyallresultDict_d=tmpF(cyResultDict[cy][0],cyallresultDict_d)
        cysnpresultDict_d=tmpF(cyResultDict[cy][1],cysnpresultDict_d)
        cyindelresultDict_d=tmpF(cyResultDict[cy][2],cyindelresultDict_d)
        cyallresultDict_a=tmpF(cyResultDict[cy][3],cyallresultDict_a)
        cysnpresultDict_a=tmpF(cyResultDict[cy][4],cysnpresultDict_a)
        cyindelresultDict_a=tmpF(cyResultDict[cy][5],cyindelresultDict_a)

    def cal_mean_std(inputDict):
        outputDict={}
        for q in inputDict.keys():
            mean=np.mean(inputDict[q])
            std=np.std(inputDict[q])
            outputDict[q]=[mean,std]
        return outputDict

    finalDict_all_d=cal_mean_std(cyallresultDict_d)
    finalDict_snp_d=cal_mean_std(cysnpresultDict_d)
    finalDict_indel_d=cal_mean_std(cyindelresultDict_d)
    finalDict_all_a=cal_mean_std(cyallresultDict_a)
    finalDict_snp_a=cal_mean_std(cysnpresultDict_a)
    finalDict_indel_a=cal_mean_std(cyindelresultDict_a)



    output_to_file(finalDict_all_d,outputFolder1+cladeName+"_all_diversity_sample"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","all")
    output_to_file(finalDict_snp_d,outputFolder1+cladeName+"_snp_diversity_sample"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","snp")
    output_to_file(finalDict_indel_d,outputFolder1+cladeName+"_indel_diversity_sample"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","indel")
    output_to_file(finalDict_all_a,outputFolder2+cladeName+"_all_ableNumRate_sample"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","all")
    output_to_file(finalDict_snp_a,outputFolder2+cladeName+"_snp_ableNumRate_sample"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","snp")
    output_to_file(finalDict_indel_a,outputFolder2+cladeName+"_indel_ableNumRaye_sample"+str(randomSamNum)+"_cycle"+str(cycleNum)+".txt","indel")



print("finished!!!!!")


