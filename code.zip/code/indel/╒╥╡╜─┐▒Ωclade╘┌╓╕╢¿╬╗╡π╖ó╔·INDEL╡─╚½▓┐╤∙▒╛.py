

inputFolder=r"F:\forStudy\studysite\indelWorksite\step1\\"

inputPosFolder=r"F:\forStudy\studysite\indelWorksite\关注基因的关注INDEL位点\\"


outputFolder=r"F:\forStudy\studysite\indelWorksite\关注基因的关注INDEL位点\位点对应的样本\\"






# cladeNameList=["2.2dONLYchina","4.2cnONLYchina","4.4cnONLYchina","4.5ONLYchina"]
cladeNameList=["allVcfStrain"]

import os
from tqdm import tqdm


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)


genePosDict={}
fileList=os.listdir(inputPosFolder)
for f in fileList:
    if ".txt" in f:
        geneName=f.split(".")[0]
        genePosDict[geneName]=[]
        with open(inputPosFolder+f,"r") as input:
            for ll in input:
                genePosDict[geneName] .append(int(ll.strip()))

for gg in genePosDict.keys():
    print(f"{gg} start ############################")
    posSet = set(genePosDict[gg])

    for ii in cladeNameList:
        print(f"{ii} start ############################")
        inputlistfile = r"G:\aaaworksite\mtbc基因组数据总结\\" + ii + ".txt"
        strainlist = []
        with open(inputlistfile, "r") as input:
            for l in input:
                strainlist.append(l.strip())


        outputDict={}
        for pp in posSet:
            outputDict[pp]=[]
        for ss in tqdm(strainlist):
            try:
                with open(inputFolder+ss+"_indel.txt","r") as input:
                    for ll in input:
                        llx=ll.strip().split()
                        if llx[0] !="Position(PreviousOneSite)":
                            key = int(llx[0]) # 同一个位点的不同indel视为一个
                            if key in posSet:
                                outputDict[key].append(ss)
                            else:
                                continue
            except FileNotFoundError:
                print(ss + "_indel.txt is NOT found !!")

        for qq in outputDict.keys():
            with open(outputFolder+gg+"_"+ii+"_"+str(qq)+"_sampleList.txt","w") as output:
                for ss in outputDict[qq]:
                    output.write(ss+"\n")


print("finished!!!!!!")


