

inputFolder=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_density_bySampleMean&Std_byRegion\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_density_bySampleMean&Std_byRegion_拆分CDS和非CDS\\"


import os

os.makedirs(outputFolder, exist_ok=True)

fileList=os.listdir(inputFolder)

# 注意，在前面的流程中剔除了小于200bp的非CDS区域

cdsList=[]
nocdsList=[]
for f in fileList:
    if "_INDEL_density_bySAMPLEmean&std_byRegion.txt" in f:
        with open(inputFolder+f,"r") as input:
            for ll in input:
                llx=ll.strip().split()
                if llx[0] !="Region":
                    if llx[1] =="CDS":
                        cdsList.append(ll.strip())
                    elif llx[1] =="outCDS":
                        nocdsList.append(ll.strip())
                    else:
                        print("wrong!!!!!!! in type!!!!!")
                else:
                    title=ll.strip()

    with open(outputFolder+f.replace(".txt","")+"_CDS.txt","w") as output:
        output.write(title+"\n")
        for rr in cdsList:
            output.write(rr+"\n")

    with open(outputFolder+f.replace(".txt","")+"_outCDS.txt","w") as output:
        output.write(title+"\n")
        for rr in nocdsList:
            output.write(rr+"\n")

print("finished!!!!!!!")