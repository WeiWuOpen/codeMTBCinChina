
inputAnnotationFile=r"G:\aaaworkfilestore\TB\TB_annatationfile\\H37Rv.annotation_all.txt"
inputrefseqFile = r"G:\aaaworkfilestore\TB\TB_annatationfile\refseq\H37Rv_r.fasta"
inputVcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"

inputSNPandINDELofH37RvFolder=r"F:\forStudy\studysite\indelWorksite\SNPandINDELofH37Rv\\"


outputFolder1=r"F:\forStudy\studysite\indelWorksite\SNPandINDEL_density_bySampleMean&Std_byRegion\\"




cladeNameList=["4.2cnONLYchina","4.2bNOchina","4.4cnONLYchina","4.4aNOchina"]
cladeNameList=["4.6789NOchina","2.2eNOchina"]
cladeNameList=["4.5ONLYchina","2.2dONLYchina"]

# cladeNameList=["allL1","allL2","allL3","allL4","allL5","allL6","allL7","allL8","allL9"]


# cladeNameList=["allL1","allL3","allL5","allL6","allL7","allL8","allL9"]

# cladeNameList=["allL2"]

# cladeNameList=["allL4"]

# cladeNameList=["allVcfStrain"]

cladeNameList=["4.8"]



gapLimit=200 # CDS之间的gap长度太短的不要了


import os
import numpy as np
import copy
import math
from tqdm import tqdm
import scipy.sparse
import bisect



os.makedirs(outputFolder1, exist_ok=True)


refseqdict = {}
with open(inputrefseqFile, "r") as input:
    for l in input:
        if l.strip()[0] != ">":
            refseq = list(l.strip())
for i in range(1, len(refseq) + 1):
    refseqdict[int(i)] = refseq[i - 1]
wholeGenomeLength=len(refseqdict)


allCDSDict = {}
with open(inputAnnotationFile, "r") as input:
    for l in input:
        lx = l.strip().split()
        if lx[2] =="CDS":
            allCDSDict[int(lx[3])] = [lx[0],int(lx[4])]


snpOFrefList=[]
with open(inputSNPandINDELofH37RvFolder+"SNPinH37Rv.txt","r") as input:
    for ll in input:
        llx=ll.strip().split()
        if llx[0] !="Pos":
            snpOFrefList.append(int(llx[0]))
snpOFrefSet=set(snpOFrefList)


INDELOFrefList=[]
with open(inputSNPandINDELofH37RvFolder+"INDELinH37Rv.txt","r") as input:
    for ll in input:
        llx=ll.strip().split()
        if llx[0] !="Pos":
            INDELOFrefList.append(int(llx[0]))
INDELOFrefSet=set(INDELOFrefList)



allCutDict=copy.deepcopy(allCDSDict)

cdsPosList=sorted(allCDSDict.keys())
for ci in range(0,len(cdsPosList)):
    if ci != len(cdsPosList)-1: # 最后一个之前
        sp=cdsPosList[ci]
        ep=allCDSDict[sp][1]
        nextsp=cdsPosList[ci+1]

        gapLength = nextsp - ep -1
        if gapLength >= gapLimit: # gap长度太短的不要了
            name=allCDSDict[nextsp][0]+"_upGap"
            gapSp=ep+1
            gapEp=nextsp -1
            allCutDict[gapSp]=[name,gapEp]
            del gapEp
            del gapSp
            del gapLength
            del name
    else:
        sp = cdsPosList[ci]
        gapSp= sp +1
        gapEp=wholeGenomeLength
        name="finalGap"
        allCutDict[gapSp] = [name, gapEp]
        del gapEp
        del gapSp
        del name



############################################################################
def cal_density2(sortFilterStrainlist,sortedUniqueinputListSNP, sortedUniqueinputListINDEL, sparse_matrixSNP,sparse_matrixINDEL,startPos, endPos, startIndexSNP, startIndexINDEL):
    rrDictSNP={}
    rrDictINDEL={}
    for sam in sortFilterStrainlist:
        rrDictSNP[sam] = 0
        rrDictINDEL[sam] = 0
    del sam

    for ii in range(startIndexSNP, len(sortedUniqueinputListSNP) ):
        pos = sortedUniqueinputListSNP[ii]
        if pos < startPos:
            continue
        elif startPos <= pos <= endPos:
            for samindex in range(0,len(sortFilterStrainlist)):
                sam = sortFilterStrainlist [samindex]
                rrDictSNP[sam] += sparse_matrixSNP[samindex,ii] # 如果矩阵中没有值，则会加0
                del sam
        else:
            startIndexSNP = ii
            break
        del pos
    del ii


    for ii in range(startIndexINDEL, len(sortedUniqueinputListINDEL) ):
        pos = sortedUniqueinputListINDEL[ii]
        if pos < startPos:
            continue
        elif startPos <= pos <= endPos:
            for samindex in range(0,len(sortFilterStrainlist)):
                sam = sortFilterStrainlist [samindex]
                rrDictINDEL[sam] += sparse_matrixINDEL[samindex,ii]
                del sam
        else:
            startIndexINDEL = ii
            break
        del pos
    del ii

    rrateListSNP=[]
    rrateListINDEL=[]
    rrateListALL=[]
    for ww in rrDictSNP.keys():
        rrateListSNP.append(   rrDictSNP[ww] / (endPos - startPos + 1)  )
        rrateListINDEL.append(  rrDictINDEL[ww] / (endPos - startPos + 1)  )
        rrateListALL.append(  (rrDictINDEL[ww] + rrDictSNP[ww]) / (endPos - startPos + 1)  )
    
    meanSNP=np.mean(rrateListSNP) # 每个样本每个碱基的snp发生率的均值
    stdSNP=np.std(rrateListSNP)    # 每个样本每个碱基的snp发生率的标准差
    
    meanINDEL=np.mean(rrateListINDEL) # 每个样本每个碱基的INDEL发生率的均值
    stdINDEL=np.std(rrateListINDEL)    # 每个样本每个碱基的INDEL发生率的标准差
    
    meanALL=np.mean(rrateListALL) # 每个样本每个碱基的ALL发生率的均值
    stdALL=np.std(rrateListALL)    # 每个样本每个碱基的ALL发生率的标准差


    return [str(meanALL)+"\t"+str(stdALL),  str(meanSNP)+"\t"+str(stdSNP), str(meanINDEL)+"\t"+str(stdINDEL),  startIndexSNP,  startIndexINDEL]


##############################################################
##############################################################


 

for cladeName in cladeNameList:
    print(cladeName +" is working #######")
    inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"

    # vcf中的snp和indel  ############################################
    strainlist=[]
    with open(inputlistFile,"r") as input:
        for ee in input:
            strainlist.append(ee.strip())


    posDictSNP={}
    posDictINDEL={}
    filterStrainlist=[]
    allposlistSNP = []
    allposlistINDEL = []
    for ss in tqdm(strainlist):
        poslistSNP=[]
        poslistINDEL=[]
        try:
            with open(inputVcfFolder+ss+".recode.vcf","r") as input:
                for ll in input:
                    llx=ll.strip().split()
                    if llx[0] != "#":
                        if llx[0] =="NC_000962.3" and llx[6] =="PASS":
                            if len(llx[3]) ==1 and len(llx[4]) ==1: # SNP
                                if int(llx[1]) not in snpOFrefSet: # 不是参考序列自己的SNP
                                    poslistSNP.append(int(llx[1]))
                            else:                                  # INDEL
                                if int(llx[1]) not in INDELOFrefSet: # 不是参考序列自己的INDEL
                                    poslistINDEL.append(int(llx[1]))


            filterStrainlist.append(ss)
            posDictSNP[ss] = poslistSNP
            posDictINDEL[ss] = poslistINDEL
            allposlistSNP += poslistSNP
            allposlistINDEL += poslistINDEL
        except FileNotFoundError:
            print(ss+".recode.vcf is NOT found !!")
        finally:
            del poslistINDEL
            del poslistSNP


    strainNum=len(filterStrainlist)
    print(f"{strainNum} / {len(strainlist)}  sample exist !!!!!")

    sortedUniqueinputListSNP = sorted(list(np.unique(allposlistSNP)))
    sortedUniqueinputListINDEL = sorted(list(np.unique(allposlistINDEL)))

    sortFilterStrainlist=sorted(filterStrainlist)
    del filterStrainlist
    del strainlist

    # 创建列表格式稀疏矩阵
    sparse_matrixSNP = scipy.sparse.lil_matrix((len(sortFilterStrainlist), len(sortedUniqueinputListSNP)))
    sparse_matrixINDEL = scipy.sparse.lil_matrix((len(sortFilterStrainlist), len(sortedUniqueinputListINDEL)))


    for si in tqdm( range(0, len(sortFilterStrainlist) ) ):
        sss=sortFilterStrainlist[si]
        sortListSNP = sorted(posDictSNP[sss])
        for pi in range(0, len(sortedUniqueinputListSNP)):
            pos = sortedUniqueinputListSNP[pi]
            # 二分法寻找是否存在
            index = bisect.bisect_left(sortListSNP, pos)
            if index < len(sortListSNP) and sortListSNP[index] == pos:
                sparse_matrixSNP[si,pi] = 1
        del index
        del sortListSNP
        
        sortListINDEL = sorted(posDictINDEL[sss])
        for pi in range(0, len(sortedUniqueinputListINDEL)):
            pos = sortedUniqueinputListINDEL[pi]
            # 二分法寻找是否存在
            index = bisect.bisect_left(sortListINDEL, pos)
            if index < len(sortListINDEL) and sortListINDEL[index] == pos:
                sparse_matrixINDEL[si,pi] = 1
        del index
        del sortListINDEL
    del sss


    # 把列表格式稀疏矩阵转化成压缩稀疏行矩阵
    sparse_matrixSNP = sparse_matrixSNP.tocsr()
    sparse_matrixINDEL = sparse_matrixINDEL.tocsr()


    ###############################################################

    resultDict={}
    startIndexSNP=0
    startIndexINDEL = 0
    for cc in tqdm(sorted(allCutDict.keys())): # key必须要从小到大排序
        name=allCutDict[cc][0]
        startPos=cc
        endPos=allCutDict[cc][1]
        midPos = str( int((startPos+endPos) / 2) )

        deResult = cal_density2(sortFilterStrainlist,sortedUniqueinputListSNP, sortedUniqueinputListINDEL, sparse_matrixSNP,sparse_matrixINDEL,startPos, endPos, startIndexSNP, startIndexINDEL)
        deResultList=deResult[0:3]
        startIndexSNP = deResult[3]
        startIndexINDEL = deResult[4]
        del startPos
        del endPos
        resultDict[name]=[midPos]+ deResultList
        del midPos

    with open(outputFolder1+cladeName+"_SNP&INDEL_density_bySAMPLEmean&std_byRegion.txt","w") as output:
        output.write("Region	Type	midPos"+"\t"+f"Mean_density_SNP&INDEL_{cladeName}"+"\t"+f"Std_density_SNP&INDEL_{cladeName}"+"\n")
        for rr in resultDict.keys():
            if "Gap" in rr:
                output.write(rr+"\t"+"outCDS"+"\t"+str(resultDict[rr][0])+"\t"+str(resultDict[rr][1])+"\n")
            else:
                output.write(rr+"\t"+"CDS"+"\t"+str(resultDict[rr][0])+"\t"+str(resultDict[rr][1])+"\n")
                
    with open(outputFolder1+cladeName+"_SNP_density_bySAMPLEmean&std_byRegion.txt","w") as output:
        output.write("Region	Type	midPos"+"\t"+f"Mean_density_SNP_{cladeName}"+"\t"+f"Std_density_SNP_{cladeName}"+"\n")
        for rr in resultDict.keys():
            if "Gap" in rr:
                output.write(rr+"\t"+"outCDS"+"\t"+str(resultDict[rr][0])+"\t"+str(resultDict[rr][2])+"\n")
            else:
                output.write(rr+"\t"+"CDS"+"\t"+str(resultDict[rr][0])+"\t"+str(resultDict[rr][2])+"\n")
    
    with open(outputFolder1+cladeName+"_INDEL_density_bySAMPLEmean&std_byRegion.txt","w") as output:
        output.write("Region	Type	midPos"+"\t"+f"Mean_density_INDEL_{cladeName}"+"\t"+f"Std_density_INDEL_{cladeName}"+"\n")
        for rr in resultDict.keys():
            if "Gap" in rr:
                output.write(rr+"\t"+"outCDS"+"\t"+str(resultDict[rr][0])+"\t"+str(resultDict[rr][3])+"\n")
            else:
                output.write(rr+"\t"+"CDS"+"\t"+str(resultDict[rr][0])+"\t"+str(resultDict[rr][3])+"\n")


print("finished!!!!!!")



























