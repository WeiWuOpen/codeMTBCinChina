

inputVcfFolder=r"G:\aaaworkfilestore\TB\store_allrecodevcf\\"
outputFolder1=r"F:\forStudy\studysite\indelWorksite\SNPandINDELofH37Rv\\"



import os
import numpy as np
import copy
import math
from tqdm import tqdm
from collections import Counter



cladeNameList=["allVcfStrain"]


os.makedirs(outputFolder1, exist_ok=True)


for cladeName in cladeNameList:
    print(cladeName +" is working #######")
    inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"

    # vcf中的snp和indel  ############################################
    strainlist=[]
    with open(inputlistFile,"r") as input:
        for ee in input:
            strainlist.append(ee.strip())



    filterStrainlist=[]
    allposlistSNP = []
    allposlistINDEL = []
    for ss in tqdm(strainlist):
        poslistSNP=[]
        poslistINDEL=[]
        try:
            with open(inputVcfFolder+ss+".recode.vcf","r") as input:
                for ll in input:
                    llx=ll.strip().split()
                    if llx[0] != "#":
                        if llx[0] =="NC_000962.3" and llx[6] =="PASS":
                            if len(llx[3]) ==1 and len(llx[4]) ==1: # SNP
                                poslistSNP.append(int(llx[1]))
                            else:
                                poslistINDEL.append(int(llx[1]))
            filterStrainlist.append(ss)
            allposlistSNP += poslistSNP
            allposlistINDEL += poslistINDEL
        except FileNotFoundError:
            print(ss+".recode.vcf is NOT found !!")
        finally:
            del poslistINDEL
            del poslistSNP

    allsnpCountDict=dict(Counter(allposlistSNP))
    allindelCountDict=dict(Counter(allposlistINDEL))
    
    strainNum=len(filterStrainlist)
    
    
    # SNP或者INDEL的存在率
    outputListSNP=[]
    for pp in allsnpCountDict.keys():
        eRate= allsnpCountDict[pp] / strainNum
        if eRate >= 0.95: # 在全部样本中存在率大于95%认为是参考基因组自带的
            outputListSNP.append(str(pp)+"\t"+str(eRate))
        else:
            continue
        del eRate
        
    outputListINDEL=[]
    for pp in allindelCountDict.keys():
        eRate= allindelCountDict[pp] / strainNum
        if eRate >= 0.95:
            outputListINDEL.append(str(pp)+"\t"+str(eRate))
        else:
            continue
        del eRate
    
    with open(outputFolder1+"SNPinH37Rv.txt","w") as output:
        output.write("Pos"+"\t"+"existRate"+"\n")
        for uu in outputListSNP:
            output.write(uu+"\n")
            
    with open(outputFolder1+"INDELinH37Rv.txt","w") as output:
        output.write("Pos"+"\t"+"existRate"+"\n")
        for uu in outputListINDEL:
            output.write(uu+"\n")
            



print("finished!!!!!")
