





inputFolder=r"F:\forStudy\studysite\indelWorksite\step2\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\step3\\"





coupleList=[["2.2eNOchina","2.2dONLYchina"],["4.2bNOchina","4.2cnONLYchina"],["4.4aNOchina","4.4cnONLYchina"],["4.6789NOchina","4.5ONLYchina"]]




import os
from tqdm import tqdm
from collections import Counter


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)



for cp in coupleList:
    outchinaCladeDict={}
    chinaCladeDict={}
    resultDict={}
    with open(inputFolder+cp[0]+"_indel_rate.txt","r") as input:
        for ll in input:
            llx=ll.strip().split()
            if llx[0] !="Pos" and llx[0] !="Position(PreviousOneSite)":
                key=llx[0]
                outchinaCladeDict[key]=float(llx[-1])
                del key
                del llx
    with open(inputFolder + cp[1] + "_indel_rate.txt", "r") as input:
        for ll in input:
            llx = ll.strip().split()
            if llx[0] !="Pos" and llx[0] !="Position(PreviousOneSite)":
                key = llx[0]
                chinaCladeDict[key] = float(llx[-1])
                del key
                del llx
    for kk in chinaCladeDict.keys():
        if kk not in outchinaCladeDict.keys():
            outchinaCladeDict[kk]=0.0
    del kk
    for kk in outchinaCladeDict.keys():
        if kk not in chinaCladeDict.keys():
            chinaCladeDict[kk]=0.0
    del kk

    for tt in chinaCladeDict.keys():
        resultDict[int(tt)]= chinaCladeDict[tt] - outchinaCladeDict[tt]

    with open(outputFolder+cp[1]+"_"+cp[0]+"_rate差值.txt","w") as output:
        output.write("Pos"+"\t"+cp[1]+"_"+cp[0]+"existRate_dif"+"\n")
        for qq in sorted(resultDict.keys()):
            output.write(str(qq)+"\t"+str(resultDict[qq])+"\n")

print("finished!!!!!")









