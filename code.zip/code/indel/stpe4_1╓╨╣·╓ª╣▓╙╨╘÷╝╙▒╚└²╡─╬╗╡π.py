



inputFolder=r"F:\forStudy\studysite\indelWorksite\step3\\"
outputFolder=r"F:\forStudy\studysite\indelWorksite\step4\\"




import os
from tqdm import tqdm
from collections import Counter


if os.path.exists(outputFolder) !=True:
    os.mkdir(outputFolder)



inputDict={}
highRateList=[]
fileList=os.listdir(inputFolder)
for ff in fileList:
    inputDict[ff.split("_")[0]]={}
    with open(inputFolder+ff,"r") as input:
        for ll in input:
            llx=ll.strip().split()
            if llx[0] !="Pos":
                key = llx[0]
                if float(llx[-1]) > 0.0: # 增加
                    highRateList.append(key)




countHighRateDict=dict(Counter(highRateList))


refindelList=[]
for cc in countHighRateDict.keys():
    if countHighRateDict[cc] == len(fileList):
        refindelList.append(cc)
    else:
        continue


for ff in fileList:
    resultDict = {}
    inputDict[ff.split("_")[0]]={}
    with open(inputFolder+ff,"r") as input:
        for ll in input:
            llx=ll.strip().split()
            if llx[0] !="Pos":
                key = llx[0]
                if key in refindelList:
                    resultDict[key]=llx[-1]





    with open(outputFolder+ff.split("_")[0]+"_"+ff.split("_")[1]+"_indel_中国枝共有增加rate的位点.txt","w") as output:
        output.write("Pos"+"\t"+ff.split("_")[0]+"_"+ff.split("_")[1]+"existRate_dif"+"\n")
        for qq in resultDict.keys():
            output.write(qq.split("\t")[0] + "\t" + str(resultDict[qq]) + "\n")







print("finished!!!!")




