

inputseqFile=r"F:\forStudy\studysite\抗原表位\TB_T细胞抗原表位MHC2.csv"
inputrefseqAAfile=r"G:\aaaworkfilestore\TB\TB_annatationfile\allGene_AA_filter.fasta"
inputgenePOSfile=r"G:\aaaworkfilestore\TB\TB_annatationfile\H37Rv.annotation_all.txt"
outputfile=r"F:\forStudy\studysite\抗原表位\TB_T细胞抗原表位MHC2_H37Rv位置.txt"

import numpy as np
from tqdm import tqdm


seqlist=[]
with open (inputseqFile,"r",encoding="utf-8") as input:
    for line in input:
        lines=input.readlines()[1:]

for ll in lines:
    llx=ll.strip().split(",")
    seqlist.append(llx[4])


refseqAAdict={}
refseqlist=[]
with open(inputrefseqAAfile,"r") as input:
    for line in input:
        refseqlist.append(line.strip())

genePosdict={}
with open(inputgenePOSfile,"r") as input:
    for line in input:
        linex=line.strip().split()
        if linex[2] =="CDS":
            genePosdict[linex[0]] = linex[3] +"\t" + linex[4]


for i in range(0,len(refseqlist)):
    if refseqlist[i][0] ==">":
        refseqAAdict[refseqlist[i].split("_")[0].replace(">","")] = refseqlist[i+1][:-1] # 去除终止密码子*


resultlist=[]


nofoundSeqList=[]
repeatfoundSeqList=[]
for seq in tqdm(seqlist):
    number=0
    for k in refseqAAdict.keys():
        if k not in genePosdict.keys():
            # print(k+" NOT in CDS!!!")
            continue
        else:
            if k[-1] != "c":
                for n in range(0,len(refseqAAdict[k])):
                    if refseqAAdict[k][n:n+len(seq)] == seq or refseqAAdict[k][n:n+len(seq)] == seq[::-1]:
                        number+=1
                        resultlist.append(k+"\t" + genePosdict[k]+"\t"+seq+"\t"+str(n+1)+"\t"+str(n+len(seq)))
            else:
                for n in range(0,len(refseqAAdict[k])):
                    if refseqAAdict[k][n:n+len(seq)] == seq or refseqAAdict[k][n:n+len(seq)] == seq[::-1]:
                        number += 1
                        resultlist.append( k+"\t" + genePosdict[k]+"\t"+seq+"\t"+str(len(refseqAAdict[k])+1-n-len(seq)+1)+"\t"+str(len(refseqAAdict[k])+1-n) )
    if number==0:
        nofoundSeqList.append(seq)
    elif number>1:
        repeatfoundSeqList.append(seq)


resultlist=np.unique(resultlist)  # 去重

print("NO found LIST:"+"_"+str(len(nofoundSeqList)))
print("repeat found LIST:"+"_"+str(len(repeatfoundSeqList)))



with open (outputfile,"w") as output:
    output.write("Gene Pos-name	Gene Start Pos	Gene Stop Pos	Amino Acid Seq	Starting Position	Ending Position"+"\n")
    for r in resultlist:
        output.write(r+"\n")

print("finished")