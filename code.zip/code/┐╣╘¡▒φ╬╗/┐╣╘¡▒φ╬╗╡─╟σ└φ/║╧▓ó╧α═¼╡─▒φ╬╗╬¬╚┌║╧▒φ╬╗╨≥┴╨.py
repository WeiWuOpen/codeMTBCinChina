

inputfile=r"F:\forStudy\studysite\抗原表位\TB_T细胞抗原表位MHC2_H37Rv位置.txt"
inputreseqAAfile=r"G:\aaaworkfilestore\TB\TB_annatationfile\allGene_AA_filter.fasta"
outputfile=r"F:\forStudy\studysite\抗原表位\TB_T细胞抗原表位MHC2_H37Rv位置_合并.txt"

import copy

## class 1 MHC 对应抗原肽长度为8-10
minCrossLength=8

## class 2 MHC 对应抗原肽长度一般为13-30
maxCrossLength=30


inputdict={}
with open(inputfile,"r") as input:
    for line in input:
        linex=line.strip().split("\t")
        if linex[0] !="Gene Pos-name":
            # 去掉一些长度异常的样本
            if  minCrossLength<= len(linex[3]) <= maxCrossLength:
                if linex[0] +"_"+linex[1] +"_"+linex[2] not in inputdict.keys():
                    inputdict[linex[0] +"_"+linex[1] +"_"+linex[2]]=[linex[3]+"_"+linex[4]+"_"+linex[5]]
                else:
                    inputdict[linex[0] +"_"+linex[1] +"_"+linex[2]] .append(linex[3]+"_"+linex[4]+"_"+linex[5])
            else:
                print(linex[0]+"\t"+linex[3])

reseqlist=[]
with open(inputreseqAAfile,"r") as input:
    for line in input:
        reseqlist.append(line.strip())
reseqAAdict = {}
for i in range(0, len(reseqlist)):
    if reseqlist[i][0] == ">":
        reseqAAdict[reseqlist[i].split("_")[0].replace(">", "")] = reseqlist[i + 1]

resultdict1={}
for k in inputdict.keys():
        resultdict1[k]=[]
        combinelist=[]
        ii=copy.deepcopy(inputdict[k])
        while True:
            commonlist = [ii[0]]
            for y in ii[1:]:
                if  int(ii[0].split("_")[1]) <=  int(y.split("_")[1]) <= int(ii[0].split("_")[2]) \
                    or int(ii[0].split("_")[1]) <=  int(y.split("_")[2]) <= int(ii[0].split("_")[2]) \
                    or int(y.split("_")[1]) <= int(ii[0].split("_")[1]) <= int(ii[0].split("_")[2]) <= int(y.split("_")[2]):
                        if min(int(ii[0].split("_")[2]),int(y.split("_")[2])) - max( int(y.split("_")[1]),int(ii[0].split("_")[1])) +1 \
                            >=minCrossLength:
                            commonlist.append(y)
                        else:
                            continue
            if len(commonlist) ==1:
                combinelist.append(ii[0])
                # print(ii[0])
                ii.remove(ii[0])
                if len(ii) ==0:
                    break
            else:
                crosslist=[]
                for y in commonlist[1:]:
                    llimit=int(commonlist[0].split("_")[1])
                    rlimit=int(commonlist[0].split("_")[2])
                    if int(y.split("_")[1]) >= int(commonlist[0].split("_")[1]):
                        llimit=int(y.split("_")[1])
                    if int(y.split("_")[2]) <= int(commonlist[0].split("_")[2]):
                        rlimit = int(y.split("_")[2])
                    crosslist.append([llimit,rlimit])
                xllimit=10000
                xrlimit=0
                # print(crosslist)
                for c in crosslist:
                    if int(c[0]) <=xllimit:
                        xllimit=int(c[0])
                    if int(c[1]) >= xrlimit:
                        xrlimit=int(c[1])
                newseq=ii[0].split("_")[0][xllimit-int(commonlist[0].split("_")[1]): xrlimit-int(commonlist[0].split("_")[1])+1]
                new=newseq + "_" + str(xllimit) + "_" + str(xrlimit)
                combinelist.append(new)
                for p in commonlist:
                    ii.remove(p)
                if len(ii) ==0:
                    break

        for t in combinelist:
            resultdict1[k].append(t)
# print(resultdict1)

resultlist2=[]
for k in resultdict1.keys():
        combinelist=[]
        ii=copy.deepcopy(resultdict1[k])
        while True:
            commonlist = [ii[0]]
            for y in ii[1:]:
                if  int(ii[0].split("_")[1]) <=  int(y.split("_")[1]) <= int(ii[0].split("_")[2]) \
                    or int(ii[0].split("_")[1]) <=  int(y.split("_")[2]) <= int(ii[0].split("_")[2]) \
                    or int(y.split("_")[1]) <= int(ii[0].split("_")[1]) <= int(ii[0].split("_")[2]) <= int(y.split("_")[2]):
                        commonlist.append(y)

            if len(commonlist) ==1:
                combinelist.append(ii[0])
                ii.remove(ii[0])
                if len(ii) ==0:
                    break
            else:
                crosslist=[]
                for y in commonlist[1:]:
                    llimit=int(commonlist[0].split("_")[1])
                    rlimit=int(commonlist[0].split("_")[2])
                    if int(y.split("_")[1]) <= int(commonlist[0].split("_")[1]):
                        llimit=int(y.split("_")[1])
                    if int(y.split("_")[2]) >= int(commonlist[0].split("_")[2]):
                        rlimit = int(y.split("_")[2])
                    crosslist.append([llimit,rlimit])
                xllimit=10000
                xrlimit=0
                for c in crosslist:
                    if int(c[0]) <=xllimit:
                        xllimit=int(c[0])
                    if int(c[1]) >= xrlimit:
                        xrlimit=int(c[1])
                if k.split("_")[0][-1] !="c":
                    newseq = reseqAAdict[k.split("_")[0]][xllimit - 1:xrlimit]
                    new=newseq + "_" + str(xllimit) + "_" + str(xrlimit)
                else:
                    reseqAASeq=reseqAAdict[k.split("_")[0]][::-1]
                    newseq = reseqAASeq[xllimit - 1:xrlimit]
                    newseq=newseq[::-1]
                    new=newseq + "_" + str(xllimit) + "_" + str(xrlimit)

                combinelist.append(new)
                for p in commonlist:
                    ii.remove(p)
                if len(ii) ==0:
                    break

        for t in combinelist:
            resultlist2.append(k+"_"+t)

with open(outputfile,"w") as output:
    output.write("Gene Pos-name"+"\t"+"Gene Start Pos"+"\t"+"Gene Stop Pos"+"\t"+"Amino Acid Seq"+"\t"+\
                 "Starting Position"+"\t"+"Ending Position" +"\n")
    for r in resultlist2:
        output.write(r.replace("_","\t")+"\n")

print("finished")
