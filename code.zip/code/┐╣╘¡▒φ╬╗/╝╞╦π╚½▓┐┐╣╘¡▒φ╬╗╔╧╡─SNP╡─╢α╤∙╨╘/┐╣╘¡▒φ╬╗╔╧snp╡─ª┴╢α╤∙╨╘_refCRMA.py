





cladeNameList = ["2.2dONLYchina", "2.2eNOchina", "4.2bNOchina", "4.2cnONLYchina", "4.4aNOchina", "4.4cnONLYchina","4.6789NOchina", "4.5ONLYchina"]

epiTypeList=["T细胞抗原表位合并"]

# epiTypeList=["T细胞抗原表位MHC2","T细胞抗原表位MHC1"]


# 每个取样点重复取样数目
repeatNum = 20



from collections import Counter
import numpy as np
import math
import os
import random
from tqdm import tqdm


# 多样性计算函数
# shannon指数
def shannon(counterDict, allNum):
    # import math
    e = math.e
    sumH = 0
    for kk in counterDict.keys():
        pi = counterDict[kk] / allNum
        if pi == 0:
            H = 0
        else:
            H = -pi * math.log(pi, e)
        sumH += H
        del H
    return sumH


# simpson指数
def simpson(counterDict, allNum):
    sumD1 = 0
    for k in counterDict.keys():
        D1 = (counterDict[k] * (counterDict[k] - 1)) / (allNum * (allNum - 1))
        sumD1 += D1
    D = 1 - sumD1
    return D


# pielou指数
def pielou(counterDict, allNum, allkindNum):
    # import math
    e = math.e
    sumH = 0
    for kk in counterDict.keys():
        pi = counterDict[kk] / allNum
        if pi == 0:
            H = 0
        else:
            H = -pi * math.log(pi, e)
        sumH += H
        del H
    J = sumH / math.log(allkindNum, e)
    return J


####################################

sampleNumList = []
for cladeName in cladeNameList:
    tmplist = []
    inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"
    with open(inputlistFile, "r") as input:
        for l in input:
            tmplist.append(l.strip())
    sampleNumList.append(len(tmplist))
    del tmplist

minNum = min(sampleNumList)
if minNum < 100:
    maxsamplingNum = int(minNum / 10) * 10
elif 100 <= minNum < 1000:
    maxsamplingNum = int(minNum / 100) * 100

print("maxsampleNum: " + str(maxsamplingNum))

########################################

for epitype in epiTypeList:
    print(epitype + " is working ##############")
    for cladeName in cladeNameList:
        print(cladeName + " is working ##############")

        inputlistFile = "G:\\aaaworksite\mtbc基因组数据总结\\" + cladeName + ".txt"
        inputepitopefile = r"F:\forStudy\studysite\抗原表位\TB_" + epitype + "_H37Rv位置_校对_合并.txt"
        inputvcfFolder = r"G:\aaaworkfilestore\TB\store_allrecodevcf_ancestralREFseq\\" + cladeName.replace("ONLYchina", "").replace("NOchina", "") + "_CRMA\\"


        inputuncoverFolder = r"G:\aaaworkfilestore\TB\store_alluncover.bed\\"
        outputFolder = r"F:\forStudy\studysite\抗原表位\α多样性_"+epitype+"_refCRMA"+"\\"


        if not os.path.exists(outputFolder):
            os.mkdir(outputFolder)

        strainlist = []
        with open(inputlistFile, "r") as input:
            for l in input:
                strainlist.append(l.strip())

        epitopedict = {}
        genedict = {}
        with open(inputepitopefile, "r") as input:
            for ll in input:
                llx = ll.strip().split("\t")
                if llx[0] != "Gene Pos-name":
                    if llx[0] not in epitopedict.keys():
                        if llx[0][-1] == "c":
                            epitopedict[llx[0] ] = [  [str(int(llx[4]) * 3 - 2 + int(llx[1]) - 1) , str(int(llx[5]) * 3 + int(llx[1]) - 1),llx[3]]  ]

                            genedict[llx[0]] = [llx[1] , llx[2]]  # 利用字典的key不能重复的特点自动去重
                        else:
                            epitopedict[llx[0]] = [  [str(int(llx[4]) * 3 - 2 + int(llx[1]) - 1) , str(int(llx[5]) * 3 + int(llx[1]) - 1),llx[3]]  ]

                            genedict[llx[0]] = [llx[1] , llx[2]]
                    else:
                        if llx[0][-1] == "c":
                            epitopedict[llx[0]].append( [str(int(llx[4]) * 3 - 2 + int(llx[1]) - 1),
                                                   str(int(llx[5]) * 3 + int(llx[1]) - 1), llx[3]] )

                            genedict[llx[0]] = [llx[1], llx[2]]  # 利用字典的key不能重复的特点自动去重
                        else:
                            epitopedict[llx[0]].append( [str(int(llx[4]) * 3 - 2 + int(llx[1]) - 1),
                                                   str(int(llx[5]) * 3 + int(llx[1]) - 1), llx[3]] )

                            genedict[llx[0]] = [llx[1], llx[2]]


        vcfdict = {}
        beddict = {}
        for i in strainlist:
            vcfdict[i] = []
            beddict[i] = []
            with open(inputvcfFolder + i + ".recode.ancestralREFseq.vcf", "r") as inputvcf, open(
                    inputuncoverFolder + i + ".uncover.bed", "r") as inputbed:
                for line in inputbed:
                    linex = line.strip().split()
                    beddict[i].append(linex[1] + "_" + linex[2])
                for l in inputvcf:
                    if l.strip()[0] != "#":
                        vcfdict[i].append(l.strip().split()[1] + "_" + l.strip().split()[3] + "_" + l.strip().split()[4])

        strainPOSDict_epi = {}
        strainPOSDict_outepi = {}
        for ss in tqdm(strainlist,desc="Sample"):
            strainPOSDict_epi[ss] = []
            strainPOSDict_outepi[ss] = []
            for vv in vcfdict[ss]:
                uncoverList = []
                ggList = []
                eeList=[]
                vcfpos = int(vv.split("_")[0])
                for u in beddict[ss]:
                    ul = int(u.split("_")[0])
                    ur = int(u.split("_")[1])
                    if ul <= vcfpos <= ur:
                        uncoverList.append(vcfpos)
                        break
                    else:
                        continue
                if len(uncoverList) != 0:
                    continue
                else:
                    for gg in genedict.keys():
                        ggl = int(genedict[gg][0])
                        ggr = int(genedict[gg][1])
                        if ggl <= vcfpos <= ggr:
                            ggList.append(vcfpos)
                            for ee in epitopedict[gg]:
                                eel=int(ee[0])
                                eer=int(ee[1])
                                if eel <= vcfpos <= eer:
                                    eeList.append(vcfpos)
                                    break
                                else:
                                    continue
                            break
                        else:
                            continue
                    if len(ggList) == 0:
                        continue
                    else:
                        if len(eeList)==0:
                            strainPOSDict_outepi[ss].append(vv)  # 这里同一位置不同突变后碱基视为不同
                        else:
                            strainPOSDict_epi[ss].append(vv)

        ########################################################################################################
        for type in ["epi","outepi"]:
            hindexDict = {}
            dindexDict = {}
            jindexDict = {}
            yy = 0
            for ii in range(0, maxsamplingNum, int(maxsamplingNum / 20)):  # 设置20个取样点
                yy += 1
                samplingNum = yy * int(maxsamplingNum / 20)
                # print(str(samplingNum) + "/" + str(maxsamplingNum))

                hindexDict[samplingNum] = []
                dindexDict[samplingNum] = []
                jindexDict[samplingNum] = []

                for re in range(0, repeatNum):
                    allPOSlist = []
                    samplingstrainlist = []
                    random.seed(samplingNum * 13 + re * 123 + 191)
                    samplingstrainlist = random.sample(strainlist, samplingNum)

                    for sss in samplingstrainlist:
                        if type=="epi":
                            allPOSlist = allPOSlist + strainPOSDict_epi[sss]
                        elif type=="outepi":
                            allPOSlist = allPOSlist + strainPOSDict_outepi[sss]

                    allNum = len(allPOSlist)
                    allSNPcountDict = dict(Counter(allPOSlist))
                    allkindNum = len(allSNPcountDict)
                    hindex = shannon(allSNPcountDict, allNum)
                    dindex = simpson(allSNPcountDict, allNum)
                    jindex = pielou(allSNPcountDict, allNum, allkindNum)
                    hindexDict[samplingNum].append(hindex)
                    dindexDict[samplingNum].append(dindex)
                    jindexDict[samplingNum].append(jindex)

                    del hindex
                    del dindex
                    del jindex
                    del allPOSlist


            with open(outputFolder + cladeName +"_"+type+ ".shannon.txt", "w") as output:
                for hh in hindexDict.keys():
                    output.write(str(hh) + "\t")
                    for hhh in hindexDict[hh]:
                        output.write(str(hhh) + "\t")
                    output.write("\n")

            with open(outputFolder + cladeName +"_"+type+ ".simpson.txt", "w") as output:
                for dd in dindexDict.keys():
                    output.write(str(dd) + "\t")
                    for ddd in dindexDict[dd]:
                        output.write(str(ddd) + "\t")
                    output.write("\n")

            with open(outputFolder + cladeName +"_"+type+ ".pielou.txt", "w") as output:
                for jj in jindexDict.keys():
                    output.write(str(jj) + "\t")
                    for jjj in jindexDict[jj]:
                        output.write(str(jjj) + "\t")
                    output.write("\n")

            with open(outputFolder + cladeName +"_"+type+ ".shannon_mean_std.txt", "w") as output:
                output.write(cladeName +"_"+type+ "_SamplingNum" + "\t" + cladeName +"_"+type+ "_Mean" + "\t" + cladeName +"_"+type+ "_Std" + "\n")
                for hh in hindexDict.keys():
                    output.write(str(hh) + "\t")
                    hhmean = float(np.mean(hindexDict[hh]))
                    hhstd = float(np.std(hindexDict[hh]))
                    output.write(str(hhmean) + "\t" + str(hhstd) + "\n")

            with open(outputFolder + cladeName +"_"+type+ ".simpson_mean_std.txt", "w") as output:
                output.write(cladeName +"_"+type+ "_SamplingNum" + "\t" + cladeName +"_"+type+ "_Mean" + "\t" + cladeName +"_"+type+ "_Std" + "\n")
                for dd in dindexDict.keys():
                    output.write(str(dd) + "\t")
                    ddmean = float(np.mean(dindexDict[dd]))
                    ddstd = float(np.std(dindexDict[dd]))
                    output.write(str(ddmean) + "\t" + str(ddstd) + "\n")

            with open(outputFolder + cladeName +"_"+type+ ".pielou_mean_std.txt", "w") as output:
                output.write(cladeName +"_"+type+ "_SamplingNum" + "\t" + cladeName +"_"+type+ "_Mean" + "\t" + cladeName +"_"+type+ "_Std" + "\n")
                for jj in jindexDict.keys():
                    output.write(str(jj) + "\t")
                    jjmean = float(np.mean(jindexDict[jj]))
                    jjstd = float(np.std(jindexDict[jj]))
                    output.write(str(jjmean) + "\t" + str(jjstd) + "\n")


            del hindexDict
            del dindexDict
            del jindexDict



print("finished!!!!!!")






